﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace C_program
{
    class Program
    {
        static void getCombinaciones<T>(List<List<T>> combinaciones, List<T> list, int index, int k, List<T> building)
        {
            if(building.Count == k)
            {
                combinaciones.Add(new List<T>(building.ToArray()));
                return;
            }
            if (index == list.Count)
            {
                return;
            }

            getCombinaciones(combinaciones, list, index + 1, k, building);

            building.Add(list[index]);
            getCombinaciones(combinaciones, list, index + 1, k, building);
            building.RemoveAt(building.Count - 1);
        }
        static List<List<T>> combinaciones<T>(List<T> list, int k)
        {
            List<List<T>> result = new List<List<T>>();

            getCombinaciones(result, list, 0, k, new List<T>());

            return result;
        }

        static void print_list_list<T>(List<List<T>> lists)
        {
            for(int i = 0; i < lists.Count; i ++)
            {
                for(int j = 0; j < lists[i].Count; j++)
                {
                    Console.Write(lists[i][j]);
                    Console.Write(", ");
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            List<int> input = Console.ReadLine().Split().Select(Int32.Parse).ToList();
            List<int> list = new List<int>();
            for(int i = 1; i <= input[0]; ++i)
            {
                list.Add(i);
            }
            
            List<List<int>> list_result = combinaciones(list, input[1]);

            print_list_list(list_result);
        }
    }
}
