/*
Timeout Utilizando select

Crea el temporizador una sola vez, fuera del ciclo, para poner un timeout
a la ejecucion del programa. (Anteriormente, existia un timeout para cada iteracion)

Esta vez el programa terminara luego de 5 segundos.
*/
package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	c := greet("Joe")
	timeout := time.After(5 * time.Second) // Termina el programa en 5 segundos.

	for {
		select {
		case s := <-c:
			fmt.Println(s)
		case <-timeout:
			fmt.Println("Timeout. I'm leaving.")
			return
		}
	}
}

func greet(name string) <-chan string { // Retorna canal de solo recepción (<-) de strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			c <- fmt.Sprintf("I'm %s - %d", name, i)
			time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
		}
	}()

	return c // Retorna el canal.
}
