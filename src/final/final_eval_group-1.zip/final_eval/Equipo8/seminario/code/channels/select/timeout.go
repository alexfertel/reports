/*
Timeout Utilizando select

La funcion `time.After` retorna un canal que permanece bloqueado durante
el tiempo especificado. Luego de ese intervalo, el canal entrega el timepo actual,
esto ocurre una sola vez.

La instruccion `select` le esta dando a la rutina `greet` 800ms para responder.
Esto seria un ciclo infinito si `greet` pudiera ejecutarse siempre en un tiempo menor
a 800ms.
*/
package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	c := greet("Joe")

	for {
		select {
		case s := <-c:
			fmt.Println(s)
		// Equivale a reiniciar el timer en cada iteracion
		case <-time.After(800 * time.Millisecond):
			fmt.Println("Timeout. I'm leaving.")
			return
		}
	}
}

func greet(name string) <-chan string { // Retorna canal de solo recepción (<-) de strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			c <- fmt.Sprintf("I'm %s - %d", name, i)
			time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
		}
	}()

	return c // Retorna el canal.
}
