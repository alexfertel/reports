package main

import (
	"fmt" 
	"math/rand"
	"time"
	"strconv"
	"sync"
)

//Queue is ...
type Queue struct {
	mutex sync.Mutex
	maxsize int
	queue []int
	total int
}

func (q *Queue) producer() {

	for true {
		if len(q.queue) < q.maxsize {
			q.mutex.Lock()
			item := rand.Intn(10)
			q.total++
			q.queue = append(q.queue, item)
			fmt.Println("Produced " + strconv.Itoa(item))
		
			timeToSleep := rand.Intn(3)
			time.Sleep(time.Duration(timeToSleep) * time.Second)
			q.mutex.Unlock()
		}
	}
}

func (q *Queue) consumer() {

	for true {
		if len(q.queue) > 0 {
			q.mutex.Lock()
			item := q.queue[0]
			q.queue = q.queue[1:]
			fmt.Println("Cosumed " + strconv.Itoa(item))
		
			timeToSleep := rand.Intn(3)
			time.Sleep(time.Duration(timeToSleep) * time.Second)
			q.mutex.Unlock()
		}
	}
}

func main()  {
	queue := Queue{
		maxsize: 3,
		queue: []int{},
		total: 0,
	}
	go queue.producer()
	go queue.consumer()
	for queue.total < 15 {
	}
}