import time
import queue
import random

queue = queue.Queue(maxsize=10)

def producer():
    if not queue.full():
        item = random.randint(1, 10)
        queue.put(item)

        print("Produced: " + str(item))

        time_to_sleep = random.randint(1, 3)
        time.sleep(time_to_sleep)

def consumer():
    if not queue.empty():
        item = queue.get()

        print("Consumed: " + str(item))

        time_to_sleep = random.randint(1, 3)
        time.sleep(time_to_sleep)

while True:
    r = random.randint(0,1)
    if r == 0:
        producer()
    else:
        consumer()