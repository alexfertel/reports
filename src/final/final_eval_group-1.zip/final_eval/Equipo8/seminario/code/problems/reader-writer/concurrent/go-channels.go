package main

import (
	"fmt" 
	"math/rand"
	"time"
)
var readcount int = 0
var tmp *int

func Reader(entry chan *int, exit chan *int, critical chan *int){
entry <- tmp
readcount++
if readcount == 1{
	critical<- tmp
}
<-entry

fmt.Println("Reader is Reading!")
Read()
fmt.Println("Reader is Finished Reading!")

exit <- tmp

readcount--
if readcount ==0{
fmt.Println("Reader is Releasing the Lock!")
<-critical
}


<-exit
}
func Read(){
	time.Sleep(time.Duration(rand.Intn(10))* time.Second)
}

func Writer(critical chan *int){
	critical<- tmp
    fmt.Println("Writer is Writing!")
    Write()
    fmt.Println("Writer is Finished Writing!")
	<-critical
    fmt.Println("Writer is Releasing the lock!")
}

func Write(){
	time.Sleep(time.Duration(rand.Intn(10))* time.Second)
}
func main(){
	entry := make(chan *int, 1)
	critical := make(chan *int, 1)
	exit := make(chan *int, 1)
	for i:=1 ; i<10; i++{
		randomNumber := rand.Intn(100)
		if randomNumber <50 {
			go Reader(entry, exit, critical)
		} else{
			go Writer(critical)
		}
	}
	time.Sleep(100*time.Second)
}