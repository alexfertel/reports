package main

import (
	"fmt" 
	"math/rand"
	"time"
	"sync"
)
var readcount int = 0

func Reader(entry sync.Mutex, exit sync.Mutex, critical sync.Mutex){
entry.Lock()
readcount++
if readcount == 1{
	critical.Lock()
}
entry.Unlock()

fmt.Println("Reader is Reading!")
Read()
fmt.Println("Reader is Finished Reading!")

exit.Lock()

readcount--
if readcount ==0{
fmt.Println("Reader is Releasing the Lock!")
critical.Unlock()
}


exit.Unlock()
}
func Read(){
	time.Sleep(time.Duration(rand.Intn(10))* time.Second)
}

func Writer(critical sync.Mutex){
	critical.Lock()
    fmt.Println("Writer is Writing!")
    Write()
    fmt.Println("Writer is Finished Writing!")

	fmt.Println("Writer is Releasing the lock!")
	critical.Unlock()
}

func Write(){
	time.Sleep(time.Duration(rand.Intn(10))* time.Second)
}
func main(){
	entry := sync.Mutex{}
	critical := sync.Mutex{}
	exit := sync.Mutex{}
	for i:=1 ; i<10; i++{
		randomNumber := rand.Intn(100)
		if randomNumber <50 {
			go Reader(entry, exit, critical)
		} else{
			go Writer(critical)
		}
	}
	time.Sleep(100*time.Second)
}