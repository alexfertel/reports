
import random
import threading
import time

 
readcount =0

def Reader(entry: threading.Lock(),exit: threading.Lock(), critical: threading.Lock()):
    global readcount
    # Se bloquea el uso de la seccion inicial del codigo q accese al readcount
    entry.acquire() 
    readcount+=1
    
    if readcount == 1:
        critical.acquire()
    
    entry.release()

    print('Reader is Reading!')
    # accion de leer
    Read()
    print('Reader is Finished Reading!')
    
    #se bloquea con el mismo proposito, que no dos hilos accedan al codigo sig
    exit.acquire()

    readcount-=1
    if readcount == 0:
        print('Reader is Releasing the Lock!')
        critical.release()

    
    exit.release()

    


def Read():
    time.sleep(random.randint(1,10))

def Writer(critical: threading.Lock()):
    
    #se bloquea el recurso sobre el que se va a escribir
    critical.acquire()

    print('Writer is Writing!')
    Write()
    print('Writer is Finished Writing!')

    print('Writer is Releasing the lock!')
    #se desbloquea el recurso que se utilizo
    critical.release()

def Write():
    time.sleep(random.randint(1,10))

def main():
    entry = threading.Lock()
    critical = threading.Lock()
    exit = threading.Lock()

    for i in range(0, 10):
        randomNumber = random.randint(0, 100)   #generar un numero random entre 0 y 100
        if(randomNumber > 50):
            Thread1 = threading.Thread(target = Reader(entry,exit,critical))
            Thread1.start()
        else:
            Thread2 = threading.Thread(target = Writer(critical))
            Thread2.start()


