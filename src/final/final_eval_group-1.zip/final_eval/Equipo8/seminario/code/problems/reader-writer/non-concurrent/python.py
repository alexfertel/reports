
import random
import time    


def Read():
    time.sleep(random.randint(1,10))

def Write():
    time.sleep(random.randint(1,10))

def main():


    for i in range(0, 10):
        randomNumber = random.randint(0, 100)   #Generate a Random number between 0 to 100
        if(randomNumber > 50):
            Read()
        else:
            Write()


