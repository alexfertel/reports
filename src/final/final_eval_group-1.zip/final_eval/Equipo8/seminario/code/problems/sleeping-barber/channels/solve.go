package main
import (
	"fmt" 
	"time"
)
// Barbershop is ...
type Barbershop struct {
	chairs chan *string
	sleep bool
}
func (b *Barbershop) barberGoToWork()  {
	for true {
		if b.sleep { continue }
		var c *string
		select {
			case c = <- b.chairs: {
				//Existe cliente para pelar
				fmt.Println(*c + " is having a haircut")
				time.Sleep(2 * time.Second)
				fmt.Println(*c + " is done")
			}
			default:
				//No existe cliente para pelar
				fmt.Println("barber is sleeping")
				b.sleep = true
		}
	}
}

func (b *Barbershop) newClient(name string) {
	fmt.Println(name + " entered the barbershop.")
	select {
		case b.chairs <- &name:
			//El cleinte se puede sentar
			fmt.Println("Waiting room is avaliable, " + name + " sat down.")
			b.sleep = false
		default:
			//El cliente no se puede sentar
			fmt.Println("Waiting room is full, " + name + " leaved.")
	}
}
func (b *Barbershop) simulation(clients []string)  {
	go b.barberGoToWork()
	for true {
		if len(clients) > 0 {
			first := clients[len(clients) - 1]
			clients = clients[:len(clients) - 1]
			b.newClient(first)
			time.Sleep(time.Second)
		} 
	}
}
func main() {	
	b := Barbershop {
		chairs: make(chan *string, 5),
		sleep: false,
	}
	clients := []string{"Bratt","Ana","Iris","Axel","Andrea","Edgar",
					"Maria","Sonia","Olga","Bernard","Berkis"}      
	b.simulation(clients)
}