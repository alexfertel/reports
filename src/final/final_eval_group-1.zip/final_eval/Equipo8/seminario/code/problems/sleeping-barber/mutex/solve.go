

package main
import (
	"fmt" 
	"time"
	"math/rand"
	"sync"
)
// Barbershop is ...
type Barbershop struct {
	mutex sync.Mutex
	len int
	barber bool
	chairs []string
	sleep bool
}
func (b *Barbershop) chairAvaliable() bool {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			return true
		}
	}
	return false
}
func (b *Barbershop) clientAvaliable() bool {
	return b.chairs[0] != " "
}
func (b *Barbershop) occupyChair(name string) {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			b.chairs[i] = name
			return
		}
	}
}
func (b *Barbershop) vocateChair() string {
	first := b.chairs[0]
	for i:= 0; i < b.len - 1; i++ {
		b.chairs[i] = b.chairs[i + 1] 
	}
	b.chairs[b.len - 1] = " "
	return first
}

//Se ejecuta como Go-Routine
func (b *Barbershop) barberGoToWork()  {
	for true {

		if b.sleep { continue }
		//Se cierra para aceder al recurso compartido
		b.mutex.Lock()
		if b.clientAvaliable() {
			first := b.vocateChair()
			b.mutex.Unlock()
			//Se termina de usar el recurso compartido
			fmt.Println(first + " is having a haircut")
			r := rand.Intn(3) + 2
			time.Sleep(time.Duration(r) * time.Second)
			fmt.Println(first + " is done")
		} else {
			b.mutex.Unlock()
			//Se termina de usar el recurso compartido
			fmt.Println("barber is sleeping")
			b.sleep = true
		}
	}
}


func (b *Barbershop) newClient(name string) {
	//Se cierra para aceder al recurso compartido
	b.mutex.Lock()
	fmt.Println(name + " entered the barbershop.")  
	if b.chairAvaliable() {
		fmt.Println("Waiting room is avaliable, " + name + " sat down.")
		b.occupyChair(name)
		b.mutex.Unlock()
		b.sleep = false
		//Se termina de usar el recurso compartido
	} else {
		fmt.Println("Waiting room is full, " + name + " leaved.")
		b.mutex.Unlock()
		//Se termina de usar el recurso compartido
	}
}




func (b *Barbershop) simulation(clients []string)  {
	go b.barberGoToWork()
	for true {
		if len(clients) > 0 {
			first := clients[len(clients) - 1]
			clients = clients[:len(clients) - 1]
			b.newClient(first)
			r := rand.Intn(3) + 2
			time.Sleep(time.Duration(r) * time.Second)
		}
	}
}

func main() {	

	b := Barbershop {
		len: 5,
		barber: false,
		chairs: []string{" ", " ", " ", " "," "},
		sleep: true,
	}
	clients := []string{"Bratt","Ana","Iris","Axel","Andrea","Edgar",
							"Maria","Sonia","Olga","Bernard","Berkis"}      
	b.simulation(clients)

}