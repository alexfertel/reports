﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using SynchronizationPrimitives;

namespace Tester
{
    class Program
    {

        #region semaphore properties
        //// A semaphore that simulates a limited resource pool.
        ////
        //private static Semaphore _pool;

        //// A padding interval to make the output more orderly.
        //private static int _padding;
        #endregion

        #region countdown properties
        static MyCountdown myCoutdown = new MyCountdown(5);
        static Random r = new Random();
        #endregion

        static void Main(string[] args)
        {
            #region testing Semaphore
            //    // Create a semaphore that can satisfy up to three
            //    // concurrent requests. Use an initial count of zero,
            //    // so that the entire semaphore count is initially
            //    // owned by the main program thread.
            //    //
            //_pool = new Semaphore(0, 3);

            //    // Create and start five numbered threads. 
            //    //
            //    for (int i = 1; i <= 5; i++)
            //    {
            //        Thread t = new Thread(new ParameterizedThreadStart(Worker));

            //        // Start the thread, passing the number.
            //        //
            //        t.Start(i);
            //    }

            //    // Wait for half a second, to allow all the
            //    // threads to start and to block on the semaphore.
            //    //
            //    Thread.Sleep(500);

            //    // The main thread starts out holding the entire
            //    // semaphore count. Calling Release(3) brings the 
            //    // semaphore count back to its maximum value, and
            //    // allows the waiting threads to enter the semaphore,
            //    // up to three at a time.
            //    //
            //    Console.WriteLine("Main thread calls Release(3).");
            //    _pool.Release(3);

            //    Console.WriteLine("Main thread exits.");

            #endregion

            #region testing Barrier

            //int count = 0;

            //// Create a barrier with four participants
            //// Provide a post-phase action that will print out certain information
            //// And the third time through, it will throw an exception
            //MyBarrier barrier = new MyBarrier(4, (b) =>
            //{
            //    Console.WriteLine("Post-Phase action: count={0}, phase={1}", count, b.CurrentPhase);
            //    if (b.CurrentPhase == 2) throw new Exception("D'oh!");
            //});

            //// Nope -- changed my mind.  Let's make it five participants.
            //barrier.AddParticipant();

            //// Nope -- let's settle on four participants.
            //barrier.RemoveParticipant();

            //// This is the logic run by all participants
            //Action action = () =>
            //{
            //    Interlocked.Increment(ref count);
            //    barrier.SignalAndWait(); // during the post-phase action, count should be 4 and phase should be 0
            //    Interlocked.Increment(ref count);
            //    barrier.SignalAndWait(); // during the post-phase action, count should be 8 and phase should be 1

            //    // The third time, SignalAndWait() will throw an exception and all participants will see it
            //    Interlocked.Increment(ref count);
            //    try
            //    {
            //        barrier.SignalAndWait();
            //    }
            //    catch (Exception bppe)
            //    {
            //        Console.WriteLine("Caught BarrierPostPhaseException: {0}", bppe.Message);
            //    }

            //    // The fourth time should be hunky-dory
            //    Interlocked.Increment(ref count);
            //    barrier.SignalAndWait(); // during the post-phase action, count should be 16 and phase should be 3
            //};

            //// Now launch 4 parallel actions to serve as 4 participants
            //Parallel.Invoke(action, action, action, action);

            //// This (5 participants) would cause an exception:
            //// Parallel.Invoke(action, action, action, action, action);
            ////      "System.InvalidOperationException: The number of threads using the barrier
            ////      exceeded the total number of registered participants."

            #endregion

            #region testing Monitor

            int nTasks = 0;
            object o = nTasks;
            List<Task> tasks = new List<Task>();

            try
            {
                for (int ctr = 0; ctr < 10; ctr++)
                    tasks.Add(Task.Run(() =>
                    { // Instead of doing some work, just sleep.
                        Thread.Sleep(250);
                        // Increment the number of tasks.
                        MonitorPool.Enter(o);
                        try
                        {
                            nTasks++;
                        }
                        finally
                        {
                            MonitorPool.Exit(o);
                        }
                    }));
                Task.WaitAll(tasks.ToArray());
                Console.WriteLine("{0} tasks started and executed.", nTasks);
            }
            catch (AggregateException e)
            {
                String msg = String.Empty;
                foreach (var ie in e.InnerExceptions)
                {
                    Console.WriteLine("{0}", ie.GetType().Name);
                    if (!msg.Contains(ie.Message))
                        msg += ie.Message + Environment.NewLine;
                }
                Console.WriteLine("\nException Message(s):");
                Console.WriteLine(msg);
            }
            // The example displays the following output:
            //        10 tasks started and executed.
            #endregion

            #region testing Countdown
            //for (int i = 0; i < 5; i++)
            //{
            //    new Thread(Consultorio).Start(i);
            //}

            //myCoutdown.Wait();
            //Console.WriteLine("Terminó el día de consultas");

            #endregion

        }

        #region semaphore auxiliar method
        //private static void Worker(object num)
        //{
        //    // Each worker thread begins by requesting the
        //    // semaphore.
        //    Console.WriteLine("Thread {0} begins " +
        //        "and waits for the semaphore.", num);
        //    _pool.WaitOne();

        //    // A padding interval to make the output more orderly.
        //    int padding = Interlocked.Add(ref _padding, 100);

        //    Console.WriteLine("Thread {0} enters the semaphore.", num);

        //    // The thread's "work" consists of sleeping for 
        //    // about a second. Each thread "works" a little 
        //    // longer, just to make the output more orderly.
        //    //
        //    Thread.Sleep(1000 + padding);

        //    Console.WriteLine("Thread {0} releases the semaphore.", num);
        //    Console.WriteLine("Thread {0} previous semaphore count: {1}",
        //        num, _pool.Release());
        //}
        #endregion

        #region countdown auxiliar method
        static void Consultorio(object i)
        {
            Thread.Sleep(r.Next(1000, 5000));
            Console.WriteLine("Llegó el paciente " + i);
            Thread.Sleep(r.Next(1000, 20000));
            Console.WriteLine("Se fue el paciente " + i);
            myCoutdown.Signal();
        }
        #endregion

    }
}
