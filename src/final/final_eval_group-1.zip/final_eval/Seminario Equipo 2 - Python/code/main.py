from seminario import *



if __name__ == "__main__":
    vector = VectorRGB(1, 2, 3)
    print(vector.red)
    print(vector.green)
    print(vector.blue)
    print(vector.redgreenblue)
    print(vector.redgreen)
    print(vector.redblue)
    vector.red = 4
    print(vector)
    vector.green = 5
    print(vector)
    vector.blue = 6
    print(vector)
    vector.redgreen = (8, 9)
    print(vector)
    print(vector.redred)
    vector.redgreenblue = 1
    print(vector)

    vector.red = "1"
