# Seminario de Lenguajes de Programación

## Equipo #1, grupo C312

### Enrique Martínez González

### Carmen Irene Cabrera Rodríguez

### David Guaty Dominguez

## Orden

Implemente en F# una función que genere todas las combinaciones de K objetos distintos escogidos
de una lista de N elementos. Haga su solución en F# y en C#. Compárelas según su simplicidad y
eficiencia. Exponga las características de F# utilizadas.

### Función en **F#**

```f#
let rec getCombinations building list k =
    match k, list with
    | 0, _          -> [building]
    | _, []         -> []
    | _, head::tail -> (getCombinations (head::building) tail (k - 1)) @ (getCombinations building tail k)

let combinations = getCombinations []
```

### Función en **C#**

```c#
    static void getCombinaciones<T>(List<List<T>> combinaciones, List<T> list, int index, int k, List<T> building)
    {
        if(building.Count == k)
        {
            combinaciones.Add(new List<T>(building.ToArray()));
            return;
        }
        if (index == list.Count)
        {
            return;
        }

        getCombinaciones(combinaciones, list, index + 1, k, building);

        building.Add(list[index]);
        getCombinaciones(combinaciones, list, index + 1, k, building);
        building.RemoveAt(building.Count - 1);
    }

    static List<List<T>> combinaciones<T>(List<T> list, int k)
    {
        List<List<T>> result = new List<List<T>>();

        getCombinaciones(result, list, 0, k, new List<T>());

        return result;
    }
```

Ambos códigos realizan la misma función, llevando a cabo la misma idea pero utilizando las características que brinda cada lenguaje. Sin lugar a dudas el código en **C#** es más extenso y verboso que el código para realizar la misma función en **F#**. Al estar en presencia de un código más simple, este es más sencillo de leer y entender que el código expuesto de **C#**. Ambas funciones utilizan la recursividad como método para obtener la solución, así que dada una entrada muy grande en ambos lenguajes podría saturarse la pila y obtener un ```stackoverflow error```. **F#** no permite la modificación de variables sin dejarlo explícito antes, y al no utilizar funciones impuras dentro del cuerpo de la función, sabemos que la función escrita es pura; por tanto, para los mismos valores de entrada se obtendrán los mismos valores de salida.

Las características de **F#** utilizadas fueron:

### Inferencia de Tipos

Para el compilador de F# no es necesario la declaración explícita de los tipos a menos que este sea incapaz de deducirlos. Omitir esta información no significa que F# sea un leguaje dinámicamente tipado, por el contrario, el compilador se encarga de deducir un tipo exacto para cada construcción; en caso de que no haya suficiente información para la inferencia, el programador deberá encargarse de realizar anotaciones explícitas en el código.

Para realizar la inferencia, se analiza el código de modo que se recolecten restricciones a partir del empleo de las variables y métodos. Estas restricciones deben ser consistentes para asegurar un buen tipado del código, en otro caso se obtiene *type error*. Las restriccionesse colectan de izquierda a derecha y de afuera hacia adentro, lo cual resulta importante porque en algunas situaciones podría afectar el proceso de inferencia.

Además, la inferencia de tipo también permite la generalización del código automáticamente; o sea, si el código de la función no depende del tipo del parámetro, el compilador considera este parámetro como *generic* sin que se necesite escribir el tipo genérico explícitamente. Esto posibilita un código genérico más legible y reusable.

La posibilidad de no tener que declarar el tipo de parámetros en la función, permite que por defecto esta sea genérica en el tipo de los objetos de la lista de la cual se quieren obtener las combinaciones, sin necesidad de especificarlo como en el caso de **C#**.

### Operaciones con listas

Las listas son estructuras de datos comúnmente utilizadas en programación funcional. En particular, las listas de F# son inmutables y están representadas en memoria como *linked lists*; a diferencia del tipo List en otros lenguajes, son bastante restrictivas en la manera de acceder a ellas y manipularlas. Aunque el módulo List ofrece variedad de funcionalidades para el uso de listas ya existentes, cuando se trata de construir dinámicamente listas solo se puede elegir entre: *cons* ```::``` y *append* ```@```.

#### Operador ```@```

La función *append* concatena dos listas. Ahora, en lugar de que el último elemento de la primera lista indique el final de la misma, este debe apuntar al inicio de la segunda lista, formando una lista nueva más larga. No obstante, como este elemento debe ser modificado con ese propósito lo que en realidad sucede es que se hace una copia completa de la primera lista.

#### Operador ```::```

El operador *cons* añade un elemento al inicio de una lista existente. Cuando este operador es utilizado, el resultado es una nueva lista; la lista de entrada no sufre cambios puesto que el trabajo consiste en asignar un nuevo elemento que esté apuntando al inicio de la lista dada. Como se puede apreciar , el hecho de que solo haya que introducir un nuevo elemento, hace que la operación *cons* sea muy rápida.

#### List range

La declaración de los elementos de una lista separados por punto y coma puede resultar tediosa en ocasiones por lo que, si se trata de elementos ordenados, se puede utilizar *list range* para la declaración. La sintaxis es de la siguiente forma:

```f#
let x = [a .. b]
```

donde a y b son los límites del intervalo; por defecto se aumenta de uno en uno, pero se puede proveer de un *step* que incluso puede ser negativo:

```f#
let x = [a .. step .. b]
```

En el ejemplo utilizado para obtener las combinaciones en el código de F#, puede observarse el uso de esta herramienta: la lista de elementos a partir de los cuales se hallan las combinaciones, son los números de 1 a n, donde n forma parte de la entrada.

#### List.map

El verdadero poder de las listas recae en los *aggregate operators* (operadores agregados), que son un conjunto de funciones útiles para cualquier colección de valores. Uno de ellos es *List.map*, una operación de proyección que crea una nueva lista basada en una función dada; cada elemento de la nueva lista es el resultado de aplicar la función al elemento de la lista original. Esta función provee una manera elegante para transformar los datos, y cuando se usa repetidamente puede simplificar la estructura del código.

Se puede apreciar su utilización en el método *formatter* del código F# entregado.

### Pattern Matching

Los patrones son reglas para transformar datos de entrada. Estos son usados en ```F#``` para comparar datos con estructuras lógicas, descomponer datos en partes o extraer información de los datos de varias maneras.

Los patrones son usados en muchas construcciones del lenguaje, como son las expresiones ```match```. También son usados cuando se procesan los argumentos de las funciones en los ```let```, expresiones lambda y en los manejadores de excepciones asociados con ```try...with``` con expresiones.

Cada patrón actúa como una regla de transformación de la entrada en alguna manera. En la expresión ```match```, cada patrón es examinado y transformado para ver si los datos de entrada son compatibles con el patrón. Si se encuentra una igualdad, la expresión resultante es ejecutada. Si una igualdad no es encontrada, la siguiente regla de patrón es probada.

Existen varios patrones en ```F#```, podríamos citar **constant pattern**, este sirve para verificar que la entrada sea cualquier número, caracter, cadena de caracteres o indentificador literal definido. También está el **cons pattern** que se utiliza para descomponer una lista en su primer elemento, la cabeza, y una lista que contiene el resto de elementos, la cola. Y otro ejemplo de Pattern matching es **wildcard pattern**, este es representado por un guión bajo (```_```) y se iguala a cualquier entrada, justo como el **variable pattern**, excepto que la entrada es descartada en lugar de asignarse a una variable. El **wildcard pattern** es usado normalmente con otros patrones como un sujetador de variables que no son necesarias en la expresión a la derecha del símbolo ```->```. También es usado frecuentemente al final de un **list pattern** para igualar cualquier entrada no igualada.

### Currying

En el código expuesto utilizamos varias veces las ventajas del **currying** en las declaraciones de funciones en ```F#```. **Currying** es un proceso que transforma una función que tiene más de un parámetro en una serie de funciones embebidas, cada una de las cuales tiene un solo parámetro. En ```F#```, las funciones que tienen más de un parámetro son inherentemente **curried**.

Por ejemplo tomemos el siguiente código:

```f#
    let compose4 op1 op2 n = op1 (op2 n)
```

El resultado de este es una función de un parámetro que retorna una función de un parámetro que resulta que retorna otra función de un parámetro, como se muestra a continuación:

```f#
    let compose4curried =
        fun op1 ->
            fun op2 ->
                fun n -> op1 (op2 n)
```

A estas funciones se pueden acceder de distintas maneras. Cada uno de los siguientes ejemplos retorna el mismo resultado. Puede sustituirse cualquiera de las dos funciones mostradas anteriormente en el siguiente ejemplo y no alterará el resultado.

```f#
    let squareIt = fun n -> n * n
    let doubleIt = fun n -> 2 * n

    // Acceder a una capa a la vez.
    System.Console.WriteLine(((compose4 doubleIt) squareIt) 3)

    // Acceder en la composición original de los ejemplos, mandando los argumentos
    // para op1 y op2, y luego aplicando la función resultante al valor.
    System.Console.WriteLine((compose4 doubleIt squareIt) 3)

    // Accediendo mandando los tres argumentos al mismo tiempo
    System.Console.WriteLine(compose4 doubleIt squareIt 3)
```

Resaltar que se puede restringir el **currying** encerrando los parámetros dentro de tuplas.

### Operador Pipelining |>

Los operadores de pipelining se utilizan para pasar parámetros a una función de una manera simple y elegante.

#### Pipelining para eliminar valores intermedios

Los operadores de pipelining permiten eliminar valores intermedios y facilitar la lectura de las llamadas a funciones. Veamos el siguiente ejemplo

```f#
// We want to create a sequence from 0 to 10 then:
// 1 Keep only even numbers
// 2 Multiply them by 2
// 3 Print the number

let mySeq = seq { 0..10 }
let filteredSeq = Seq.filter (fun c -> (c % 2) = 0) mySeq
let mappedSeq = Seq.map ((*) 2) filteredSeq
let finalSeq = Seq.map (sprintf "The value is %i.") mappedSeq

printfn "%A" finalSeq
```

En este código existen muchas definiciones intermedias de variables para llegar a la lista final. Al usar el operador de pipelining |> podemos tener un código más elegante y fácil de leer.

```f#
// Using forward pipe,
// we can eliminate intermediate let biding

let finalSeq =
    seq { 0..10 }
    |> Seq.filter (fun c -> (c % 2) = 0)
    |> Seq.map ((*) 2)
    |> Seq.map (sprintf "The value is %i.")

printfn "%A" finalSeq
```

#### Pipelining para componer funciones

También podemos usar este operador para componer funciones de una manera elegante y fácil de leer.

```F#
let negate x = x * -1
let square x = x * x

let squareNegate x = x |> square |> negate
```

#### Pasando varios parámetros al operador

Si desea pasar varios parámetros al operador de pipelining, debe agregar un | para cada parámetro adicional y crear una tupla con los parámetros. El operador de pipelining nativo F # admite hasta tres parámetros (|||> o <|||).

```f#
let printPerson name age =
    printf "My name is %s, I'm %i years old" name age

("Foo", 20) ||> printPerson

```

### Funciones como ciudadanos de primera clase

Una característica definitoria de los lenguajes de programación funcionales es la elevación de funciones al estado de primera clase. Debería poder hacer con una función todo lo que pueda hacer con los valores de los otros tipos incorporados y poder hacerlo con un grado de esfuerzo comparable.

En F# las funciones son ciudadanos de primera clase, por lo que:

1. Puede vincular funciones a identificadores, es decir, puede darles nombres.
2. Puede almacenar funciones en estructuras de datos, como en una lista.
3. Puede pasar una función como argumento en una llamada a función
4. Puede devolver una función desde una llamada a función.

#### Funciones de orden superior

Los puntos 3 y 4 dan paso a las funciones de orden superior. Una función de orden superior es una función que hace al menos una de las siguientes acciones:

1. Toma una o más funciones como argumentos.
2. Devuelve una función como resultado.

A veces, es importante ejecutar algún tipo de operación en los elementos de un conjunto de datos, pero esta operación en particular se define en el momento de la ejecución. A veces simplemente no hay forma de saber qué acción queremos tomar, excepto que necesitamos hacer algo en algún momento en particular, pero es completamente desconocido.

En un ejemplo de lo anterior es el módulo List del namespace FSharp.Collections. Este módulo posee funciones de orden superior que reciben una función como parámetro y le aplican a cada elemento de la lista la función de entrada. Ejemplos son: List.map, List.filter, List.fold.

#### Continuation-passing style

Las funciones de orden superior tienen varias aplicaciones, una de ellas es poder usar el estilo de programación Continuation-passing style.

Veamos el siguiente código en C#

```C#
public int Divide(int top, int bottom)
{
    if (bottom==0)
    {
        throw new InvalidOperationException("div by 0");
    }
    else
    {
        return top/bottom;
    }
}
```

Hay un punto sutil en este enfoque que hay que considerar: la función llamada siempre decide qué hacer.

Por ejemplo, la implementación de Divide ha decidido que lanzará una excepción. Pero, ¿y si no quiero una excepción? Tal vez quiera un int que acepte valores NULL, o tal vez lo voy a mostrar en una pantalla como "# DIV / 0". ¿Por qué lanzar una excepción que tendré que atrapar inmediatamente? En otras palabras, ¿por qué no dejar que la persona que llama decida qué debe suceder, en lugar de la función llamada?

Entonces esto es lo que son las continuaciones. Una continuación es simplemente una función que se pasa a otra función para indicarle qué hacer a continuación.

```C#
public T Divide<T>(int top, int bottom, Func<T> ifZero, Func<int,T> ifSuccess)
{
    if (bottom==0)
    {
        return ifZero();
    }
    else
    {
        return ifSuccess( top/bottom );
    }
}
```

Tenga en cuenta que las funciones de C # se han cambiado para devolver una T genérica ahora, y ambas continuaciones son una Func que devuelve una T.

Bueno, pasar muchos parámetros Func siempre se ve bastante feo en C #, por lo que no se hace con mucha frecuencia. Pero pasar funciones es fácil en F #, lo cual es una clara ventaja sobre C#, así que veamos cómo se adapta este código.

```f#
let divide ifZero ifSuccess top bottom =
    if (bottom=0)
    then ifZero()
    else ifSuccess (top/bottom)
```

Note que la función ifZero está como primer parámetro, esto es para poder usar la función como una aplicación parcial, otra característica de F#.
