﻿// Learn more about F# at http://fsharp.org

open System

let rec getCombinations building list k = 
    match k, list with
    | 0, _          -> [building]
    | _, []         -> []
    | _, head::tail -> (getCombinations (head :: building) tail (k - 1)) @ (getCombinations building tail k)

let combinations = getCombinations []

let formatter f sep list = List.map f list |> String.concat sep
let format_list          = formatter (fun l -> l.ToString()) ", "
let format_matrix        = formatter format_list "\n"

[<EntryPoint>]
let main argv =
    let argList = argv |> List.ofSeq
    match argList with
    | _::n::k::[] -> printfn "%s" (format_matrix (combinations [1 .. (int n)] (int k)))
    | _           -> failwith "Wrong arguments"
    0 // return an integer exit code
