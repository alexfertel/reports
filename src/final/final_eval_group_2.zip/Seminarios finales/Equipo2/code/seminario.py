from typing import Type

#Descriptor componente
class component:
    def __init__(self, type):
        self.type = type

    def __set_name__(self, owner, name):
        self.name = name

    def __set__(self, obj, value):
        try:
            self.type(value)
            obj.__dict__[self.name] = value
        except:
            raise Exception("No se puede asignar un valor de tipo diferente")
        
    def __get__(self, obj, objType = None):
        if obj is None:
            try:
                return objType.__dict__[self.name]
            except Exception:
                raise AttributeError()
        return obj.__dict__[self.name]
        


        

#Decorador para la clase Vector
def componentized(cls: Type):
    class wrapper:
        
        def __init__(self, *args):
            self.wrappedInstance = cls(*args) # instancia de la clase que se quiere modificar
        
        def filterAttributesByComp(self, item):
            attributes = [attr for attr in dir(cls) if isinstance(getattr(cls, attr), component)] # extraer todos los atributos de tipo componente
            try:
                comp = next(filter(lambda x: item.startswith(x), attributes))
                return comp
            except StopIteration:
                raise AttributeError(item)
        
        # Extrae las componentes cuyo nombre está contenido en item
        def getAttrList(self, item):
            result = []
            while item:
                comp = self.filterAttributesByComp(item)
                result.append(comp)
                item = item[len(comp):]
            return result


        def __getattr__(self, item: str):
            item = self.getAttrList(item)
            
            if len(item) == 1:
                return self.wrappedInstance.__getattribute__(item[0])
            else:
                return tuple([self.wrappedInstance.__getattribute__(x) for x in item])
            

        def __setattr__(self, item: str, value):  

            if len(self.__dict__) == 0:  # si es la inicialización de la clase
                self.__dict__[item] = value

            else:
                item = self.getAttrList(item)
                alreadyset = {x: False for x in item}  # para controlar las componentes que ya fueron asignadas en el llamado a __setattr__ actual
                itemlength = len(item)
                valueslist = None  # lista que guarda los valores a asignar

                if isinstance(value, tuple): # si los valores a asignar fueron entrados en una tupla
                    if len(value) == itemlength:
                        valueslist = value
                    else:
                        raise Exception("El número de valores debe ser 1, o coincidir con el número de componentes")
                else:
                    valueslist = [value] * itemlength

                for x, y in zip(item, valueslist):
                    if alreadyset[x]:
                        raise Exception("Error. Una componente no se puede repetir en una asignación múltiple")
                    alreadyset[x] = True
                    setattr(self.wrappedInstance, x, y)
            
        def __str__(self):
            return self.wrappedInstance.__str__()
        
        def __repr__(self):
            return self.wrappedInstance.__repr__()

    return wrapper

@componentized
class Vector2d:
    x = component(float)
    y = component(float)

    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
    
    def __str__(self):
        return f'({self.x}, {self.y})'

    def __repr__(self):
        return f'Vector2d: ({self.x}, {self.y})'

@componentized
class Vector3d:
    x = component(float)
    y = component(float)
    z = component(float)

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def __str__(self):
        return f'({self.x}, {self.y}, {self.z})'

    def __repr__(self):
        return f'Vector3d: ({self.x}, {self.y}, {self.z})'

@componentized
class VectorRGB:
    red = component(float)
    green = component(float)
    blue = component(float)

    def __init__(self, x, y, z) -> None:
        self.red = x
        self.green = y
        self.blue = z
    
    def __str__(self):
        return f'({self.red}, {self.green}, {self.blue})'

    def __repr__(self):
        return f'ColorRGB: ({self.red}, {self.green}, {self.blue})'