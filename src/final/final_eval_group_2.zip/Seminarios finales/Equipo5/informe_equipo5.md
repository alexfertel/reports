# Programación Funcional II

La programación funcional es un paradigma de programación declarativa que utiliza modelos de funciones basadas en funciones
matemáticas. En este estilo de programación, los programas se ejecutan mediante la evaluación de expresiones.

En los lenguajes funcionales, las funciones son *first-class* : pueden ser usadas como cualquier otro valor, pasadas como
argumentos o *inputs* de otras funciones, y ser el resultado de la evaluación de otras funciones. Ser *first-class*
también significa que es posible defnirlas y manipularlas dentro del cuerpo de otras funciones.

## *Features* de los lenguajes funcionales

### Funciones de orden superior

Las funciones de orden superior son funciones que pueden tomar como argumentos otras funciones, o retornarlas como resultado. Debido a que las funciones en programación funcional son *first-class* , entonces estos lenguajes cuentan con funciones de orden superior.

### *Purity*

La palabra *purity* en un lenguaje funcional se refiere, principalmente, a la presencia o no de *side effects* en
sus expresiones. Se dice
que una expresión o función tiene *side effects* si modifcia el estado del valor de alguna variable fuera del ámbito
de la expresión,o en general, tiene un efecto más a parte de retornar un valor. Cuando un lenguaje funcional es *puro* cuenta con las siguientes características:

* Datos inmutables:
    Típicamente en los lenguaje funcionales *puros* se operan con datos inmutables. En vez de alterar los valores existentes
    se crean copias con los nuevos valores y la original es preservada. Como las partes de la estructura que no han sido cambiadas no pueden ser modificadas, se puede, en ocasiones, compartir la copia vieja y las nuevas para ahorrar memoria.

* *Referential transparency*:
    Esta es la principal característica que describe a un lenguaje funcional puro. Una expresión se dice que es
    *referentially transparent*  si puede ser sustituida con su valor correspondiente sin cambiar el comportamiento
    del programa. Esto requiere que la expresión sea *pura*, es decir, el valor de la expresión debe ser el mismo
    para la misma entrada cada vez que es invocado y no puede tener *side effects*.

A pesar de que hay muchos lenguajes funcionales que no son *puros* (F# por ejemplo), por lo general contienen un subconjunto que sí lo es.

### Recursividad

La iteración en lenguajes funcionales se logra a través de la recursión. Estos lenguajes suelen carecer de estrucuras
de control como *while* y *for*. Estos mecanismos se suelen simular a través de la recursividad. Las funciones de orden
superior pueden se usadas como abstracción para implementar ciertos patrones de recursión, como los *catamorfismos*
y los *anamorfismos* (*folds* y *unfolds* respectivamente).

## Haskell

Haskell es un lenguaje de programación funcional *puro*, estáticamente tipado, con inferencia de tipos y evaluación de expresiones *lazy*. Es fuertemente tipado y cuenta
con numerosos *features* como *type classes*. Su nombre esta inspirado en el lógico
estadounidense Haskell Curry, quien hizo aportes en el cálculo lambda.

### Sintaxis basica

#### Operadores basicos

Haskell cuenta con la mayoría de los operadores aritméticos y booleanos de otros lenguajes de programación. A continuación se muestran algunos:

```haskell
2^3 -- exponenciacion
3 + 4 -- suma
10 - 5 -- resta
4 * 6 -- multipicacion
True || False -- or
True && True -- and
not True -- not
10 == 12 -- equals
10 /= 12 -- not equals
```

> Es importante aclarar que al utilizar los operadores aritméticos con numeros
> negativos, estos se deben encerrar entre paréntesis, de lo contrario daría error.
> Por ejemplo:
>
> ```haskell
>2 * (-3) -- correcto
>2 * -3 -- lanza error
>```

#### Funciones

Las expresiones son la unidad básica de Haskell, y las funciones son un tipo específico de expresión.
Las funciones en Haskell están estrechamente relacionadas con las funciones matemáticas, ellas convierten
un *input* o conjunto de *inputs* en un *output*.

##### Definiendo una función

Toda declaración de una función en Haskell empieza con el nombre de la misma. Luego le siguen los
parámetros separados por espacios. Despues el signo `=`, seguido del cuerpo de la función.
A continuación se muestran dos ejemplos:

```haskell
double x = x*3
sum x y = x + y
```

#### Listas

En Haskell las listas son estructuras de datos homogéneas: todos sus elementos tienen que
ser del mismo tipo. Las listas se declaran entre corchetes y cada uno de sus miembros se separa por comas.

```haskell
listOfNumbers = [1,2,3,5]
listOfNames = [,"Andy", "Richard","Adrian" ]
listOfChars = ['a','b','c']
```

> En Haskell los _string_ en realidad son listas de _chars_. Por ejemplo
> el _string_ "Hello" es en realidad la lista ['H','e','l','l','o']

#### Operadores basicos con listas

##### Concatenacion

Uno de los operadores más comunes cuando se trabaja con listas es la concatenación.
En Haskell, esto se logra usando el operador **++**:

```haskell
Prelude> [1,2,3] ++ [4,5,6]
[1,2,3,4,5,6]
```

Si se quiere añadir algún elemento al principio de una lista se puede usar el operador
**:** .

```haskell
Prelude> 'a':"drian"
"adrian"
Prelude> 0:[1,2,3,4,5]
[0,1,2,3,4,5]
```

Note que el primer operando debe ser del mismo tipo que los elementos de la lista.

##### Acceder a los elementos de una lista

Si se quiere acceder a los elementos de una lista a través de un índice se puede usar
el operador **!!**. Como en la mayoría de los lenguajes de programación, los índices de las
listas empiezan en 0:

```haskell
Prelude> "Hola Mundo" !! 3
'a'
Prelude> [1,2,3,4,5,6] !! 0
1
```

##### Comparacion de listas

En Haskell las listas se pueden comparar si sus elementos son comparables. Cuando se usa
**<**, **<=**, **=>** y **>** para comparar dos listas, la comparación se hace en orden lexicográfico.

```haskell
Prelude> [3,2,1] > [2,1,0]
True
Prelude> [3,2,1] > [2,10,100]
True
Prelude> [3,4,2] < [3,4,3]
True
Prelude> [3,4,2] > [2,4]
True
Prelude> [3,4,2] == [3,4,2]
True
```

##### List comprehensions

*List comprehensions* es una forma de crear una nueva lista a partir de una lista o varias listas. Esta idea viene
directamente del concepto de compresión de conjuntos en matemática. Debe existir al menos una lista, llamada
*generator*, que es el *input*  del *List comprehensions*. Pueden existir condiciones para determinar que elementos
se escogen o funciones que se aplican a dichos elementos.

Empecemos por un ejemplo sencillo:

```haskell
[x^2 | x <- [1..10]]
```

El *pipe* indica la separacion entre la función que se aplica para la salida, y la entrada. La entrada es una lista generadora (`[1..10]`) y la variable (`x`) sobre la cual se va a iterar esos elementos. La traducción de la sentencia anterior sería algo así: "de una lista de números del 1 al 10, selecciona (`x<-`) el cuadrado de cada uno (`x^2`) ".

Las *List comprehensions*  también pueden tener predicados que limitan la cantidad de elementos que se toman de las
listas generadoras. Estos predicados deben devolver un valor de tipo `Bool`, luego solo se pasan a la función para
la salida aquellos elementos que evaluaron `True` en el predicado.

```haskell
Prelude> [x^2 | x <- [1..10], rem x 2 == 0]
[4,16,36,64,100]
```

También es posible tener varios generadores:

```haskell
Prelude> [x^y | x <- [1..5], y <- [2, 3]]
[1,1,4,8,9,27,16,64,25,125]
```

Como se puede apreciar en la salida, lo que se hace es generar todas las posibles tuplas con los valores
`x` y `y`.

## F\#

F# es un lenguaje multiparadigma de propósito general fuertemente tipado. Soporta programación funcional, imperativa
y orientada a objetos. Fue desarrollado por Microsoft y forma parte de la plataforma .NET.

### Sintaxis basica

En F#, el *keyword* usado para declarar *data*, funciones o expresiones evaluadas es `let`. El lado izquierdo
es usualemente un identificador, pero también puede ser un *pattern*. También puede ser una función, seguida
por una secuencia de argumentos separados por espacio (al igual que en Haskell).

```fsharp
let c = 12
let sum a b = a + b
```

#### Condicionales

Una construcción básica en F# es la instrucción `if\then\else\elif`. A continuación se muestra un ejemplo:

```fsharp
let round x =
    if x >= 100 then 100
    elif x < 0 then 0
    else x
```

#### Definiendo funciones recursivas

El siguiente código muestra la declaración de una función recursiva en F#:

```fsharp
let rec factorial n = if n <= 1 then 1 else n * factorial (n - 1)
```

En este ejemplo se aprecia el *keyword* `rec`. Las funciones en F# no son recursivas por defecto, por ello
es necesario usar `rec`.

#### Listas

Una de las estructuras de datos más usadas en lenguajes funcionales son las listas.
En F# se declaran explícitamente con los elementos entre `[]`:

```fsharp
let oddPrimes = [3; 5; 7; 11]
let morePrimes = [13; 17]
```

Algunas operaciones definidas por el lenguaje son las siguientes:

```fsharp
[] // lista vacia
1 :: [2;3] // concatenacion de un elemento con una lista
[1 .. 99] // range
[1;2] @ [3] // concatenacion de dos listas
```

La librería de F# también incluye un módulo `List` que contine algunas funciones para trabajar con listas

## *Pattern Matching*

*Pattern matching* en los lenguajes funcionales consiste en el *elimination construct* para algún valor.
<!-- los *algebraic data types*. -->
*Elimination construct* significa cómo consumir o usar dicho valor.

<!-- Ahora, ¿que son los *algebraic data types*? La idea intuitiva detras de este concepto es poder definir tipos, asi como
todas las formas en que se pueden crear los mismos. Los tipos *built in*  pertenecen a esta clase. Pero tambien es posible crear nuevos tipos. -->
En Haskell, por ejemplo, se puede crear un tipo árbol binario de la siguiente forma:

```haskell
data Tree = Empty
        | Leaf Int
        | Node Tree Tree
```

Aqui, `Empty` representa un árbol vacío, `Leaf` contiene algún valor y `Node` representa los nodos que no son hojas.
Si se define la función `depth`, podemos hacer *pattern matching* como se muestra a continuación:

```haskell
depth Empty =  0
depth (Leaf n) = 1
depth (Node l r) = 1 + max(depth l) (depth r)
```

Existe más de una sintaxis para utilizar *pattern matching* en F#, así como existe más de una aplicación para esta instrucción.

Acá utilizamos la instrucción `when` para que el *pattern* machee solamente si `n` es menor que 0, lo cual es incorrecto para calcular el n-ésimo número de Fibonacci.

```fsharp
let rec fibN n =
    match n with
    | n when n <= 0 -> failwith "value must be greater than 0"
    | 1 -> 1
    | 2 -> 1
    | n ->  fibN (n-1) + fibN (n-2)
```

En este otro utilizamos múltiples *matches* en un mismo caso, mostrando que esto también es posible y bastante útil para factorizar código. Además, utilizamos el token `_`, el cual en F# es utilizado para señalar el compilador que es irrelevante para nosotros este valor.

```fsharp
let stringToBoolean x =
    match x with
    | "True"  | "true" -> true
    | "False" | "false" -> false
    | _ -> failwith "input incorrecto"
```

## Quicksort

Uno de los principales atractivos de la programación funcional, es la elegancia con la que se define un código. Si comparamos un programa escrito en F# siguiendo el paradigma funcional o en Haskell, con el programa equivalente usando  un paradigma imperativo, lo primero que salta a la vista es que la sintaxis en los lenguajes funcionales es mucho menos *verbose*. Comparemos una implementación de quicksort en F# y Haskell con una en C#.

Primeramente enunciemos los pasos a seguir por el algoritmo quicksort:

1. Tomar el primer elemento pivote **p** (en estas implementaciones tomaremos como pivote siempre el primer elemento de la lista).

2. Buscar todos los demás elementos en la lista que sean menores que **p**, y aplicar quicksort a dicha lista.

3. Buscar todos los demás elementos en la lista que sean mayores o iguales que **p**, y aplicar quicksort a dicha lista.

4. Combinar los tres conjuntos de elementos de la siguiente forma: {quicksort(los menores que **p**)} + {**p**} + {quicksort(los mayores o iguales que **p**)}

A continuacion se muestra el codigo en C# y F# respectivamente.

```csharp
public class QuickSortF
{
    public static List<T> QuickSort<T>(List<T> values) where T : IComparable
    {
        if( values.Count == 0 )
        {
            return new List<T>();
        }
        T x = values[0];
        var menores = new List<T>();
        var mayores = new List<T>();
        for(int i = 1; i < values.Count; i++){
            var e = values[i];
            if(e.CompareTo(x) < 0){
                menores.Add(e);
            }
            else{
                mayores.Add(e);
            }
        }
        var result = new List<T>();
        result.AddRange(QuickSort(menores));
        result.Add(x);
        result.AddRange(QuickSort(mayores));
        return result;
    }
}
```

```fsharp
let rec quicksort list =
   match list with
   | [] ->
        []
   | x::resto ->
        let menores =
            resto
            |> List.filter (fun e -> e < x)
            |> quicksort
        let mayores =
            resto
            |> List.filter (fun e -> e >= x)
            |> quicksort
        List.concat [menores; [x]; mayores]
```

Si comparamos ambas implementaciones, podemos ver que en F# el código prácticamente se lee como el algoritmo descrito al inicio. F# es mucho más limpio y declarativo (qué hacer), mientras que C# es más imperativo (cómo hacerlo).

Echemos un vistazo al código en F#, y analicémoslo línea a línea.
Primeramente cabe resaltar que en todo el programa no hay ni una sola declaración del tipo de las expresiones, y si bien es posible usar *data annotations* para eliminar ambigüedades en este sentido, por lo general no es común declarar tipos en F#. El algoritmo propuesto ordenará cualquier lista de elementos comparables, lo cual aplica a casi todos los tipos de F# porque todos tienen por defecto una función para comparar.
La función es recursiva, lo cual se indica usando el *keyword* `rec`.
La instrucción `match list with` emplea *pattern matching*, el cuál permite simular la concatenación de instrucciones `if then else`, algo parecido a la instrucción `switch/case` de C#, pero es bastate más flexible y poderosa que estos. *Pattern matching* permite al programador machear patrones sobre valores o sobre tipos, además se usa para manejar excepciones durante la ejecución.
En este caso, `match list with [] -> []` machea `list` con una lista vacía, y devuelve una lista vacía. Luego, `match x::resto` solamente machea sobre una lista no vacía, y define dos valores, `x` como el primer elemento de la lista, y `resto`, como los demás elementos de la lista, declarando y asignando dos valores a la vez.
`let menores` declara la variable `menores`, y le asigna mediante la función `e -> e<x` todos aquellos elementos de resto estrictamente menores que `x`.
Con `|>` se indica que el resultado de la expresión anterior hace *pipe* a la función quicksort para resolver el problema de ordenar los menores de manera recursiva.
De manera análoga, pero usando la función  `e -> e >= x` se resuelve el mismo problema para los mayores de manera recursiva.
Finalmente, se concatena el resultado de manera ordenada, y se "retorna". Note que el valor que retorna una función se corresponde con la última de sus expresiones, dado que en F# no se utiliza la *keyword* `return`.

De hecho, nuestra funcion quicksort es bastante *verbose* para los estándares de F#. Otra implementación más elegante sería:

```fsharp
let rec quicksort2 = function
   | [] -> []
   | x::resto ->
        let menores,mayores= List.partition ((>=) x) resto
        List.concat [quicksort2 menores; [x]; quicksort2 mayores]
```

En este código, el *keyword* `function` de F# trata la función como una función anónima que recibe un parámetro y devuelve un solo valor. La otra instrucción novedosa es `List.partition`, el cuál dada una función, retorna la partición resultante de aplicar ese predicado a cada elemento de resto.

En el caso de Haskell, el quicksort se puede implementar de la siguiente manera:

```haskell
quicksort []     = []
quicksort (p:xs) = (quicksort lesser) ++ [p] ++ (quicksort greater)
    where
        lesser  = filter (< p) xs
        greater = filter (>= p) xs
```

Nótese que aquí también se usa *pattern matching*, pues para el caso en que se pase una lista vacía se retorna
`[]`. En el resto de los casos se hace exactamente lo que decribe el algorimto: quicksort con los elementos menores
que el pivote **p** y quicksort con los mayores que **p**, para luego concatenar. Con la instruccion `where` podemos declarar
las funciones `lesser` y `greater` después de su uso en la expresión. Aquí se evidencia una vez más la expresividad de
los lenguajes funcionales. En pocas líneas se ha logrado implementar un algoritmo que usando el paradigma imperativo
hubera sido más extenso. Pero no se queda aquí, si usamos *list comprehension* es posible recrear una solución aún
más compacta todavía:

```haskell
quicksort (p:xs) = quicksort [x | x<-xs, x<p] ++ [p] ++ quicksort [x | x<-xs, x>=p]
```

## Problema de las N reinas

El problema de las **N** reinas consiste en determinar si es posible colocar **N** reinas en un tablero de ajedrez de dimensiones
**NxN**, de manera que ninguna reina esté amenazada por otra. La idea que se va usar para resolver el problema
es la siguiente:

1. Se empieza en la columna más a la izquierda
2. Si todas la reinas se pudieron colocar, entonces se retorna `True`.
3. En caso contrario, se intenta colocar la i-ésima reina en la i-ésima columna, probando con cada una de las filas
   donde se pueda colocar sin estar amenazada por las restantes reinas que ya han sido colocadas. Esta
   posición se marca. Si colocar la
   reina i-ésima en la posicion `(row,i)` genera una solución, se  retorna `True`. Si no es posible generar una solución
   , entonces se desmarca la posción `(row,i)` y se sigue intentando con el resto de las filas.
   Si se probaron todas las posibles filas y no se encontró ninguna solución, entonces se retorna `False`.

Veamos como podemos implementar la solución porpuesta anteriormente usando el paradigma de programacion funcional
en F# y usando programacion imperativa en C#, para luego compararlas.

En el caso de F# el código es el siguiente:

```fsharp
let notValid (x, y) (x1, y1) =
    x = x1 || y = y1 || (x - y) = (x1 - y1) || (x + y) = (x1 + y1)


let isSafe (newpos) (pos) =
    not (List.exists (fun position -> notValid (newpos) (position)) pos)


let rec NQueens queens i n =
    if i = n
    then true
    else
        [0..n-1]
        |> List.exists (fun x -> (isSafe (x, i) queens) && NQueens ((x,i)::queens) (i + 1) n)
```

La solución cuenta con tres funciones:

* `notValid`:
    Recibe un par de coordenadas en el tablero y devuelve `True` en caso de que estén en las mismas líneas horizontales, verticales o
    en las diagonales.
* `isSafe`:
     Revisa si en la posición de la nueva reina, esta se encuentra amenazada por alguna de las anteriores. En caso afiramtivo retorna `False`.
* `NQueens`:
    Aquí es donde están las instrucciones con las que se resuelve el problema auxiliandose de las dos funciones anteriores.

Esta implementación de F# es puramente funcional. La funcion `notValid` no modifica ni depende de ningun valor fuera de su ámbito. Además, es pura ya que no lleva a cabo ninguna otra acción que no sea devolver un valor de retorno. Lo mismo sucede con `isSafe`
y `NQueens`. Por tanto, ninguna de las funciones tiene *side effects*, por lo que se respeta
el *referential transparency*. Además, en F# los valores son inmutables por defecto, por lo que se utiliza esta característica en esta
solución. Nótese que cada vez se llama a `NQueens` recursivamente se pasa una nueva lista.

En el caso de C# la solución equivalente es la siguiente:

```csharp
        static bool NotValid(int x, int y, int x1, int y1)
        {
            return x == x1 || y == y1 || x - y == x1 - y1 || x + y == x1 + y1;
        }

        static bool IsSafe(List<(int,int)> queens, int newRow, int newCol)
        {
            foreach ( var position in queens)
            {
                (int row, int col) = position;
                if (NotValid(row, col, newRow, newCol))
                    return false;
            }
            return true;
        }

        static bool NQueens(List<(int,int)> queens, int col, int N)
        {
            if (col >= N)
                return true;
            for (int i = 0; i < N; i++)
            {
                if (IsSafe(queens, i, col))
                {
                    queens.Add((i,col));
                    if (NQueens(queens, col + 1, N) == true)
                        return true;
                    queens.Remove((i,col));
                }
            }
            return false;
        }
```

Aquí se usan los mismas funciones (o mejor dicho métodos), sin embargo al usar el paradigma imperativo hay diferencias. La primera
diferencia es la lista `queens`. En F#, al ser los datos inmutables (la solución que presentamos) era necesario crear una nueva
lista de posiciones por cada llamado recursivo. En el caso de la implementación imperativa podemos pasar la misma lista, haciéndole
modificaciones. Lo otro que salta a la vista es el uso de las instrucción `for`. En la implementación imperativa no se usó ninguna
estructura de este estilo: el mismo resultado se logró haciendo uso de funciones solamente.

Otra diferencia es la mencionada en la solución del problema anterior: la extensión del código. Observe que
las soluciones son equivalentes y se basan en el mismo algoritmo para resolver el problema (incluso usan las mismas funciones/métodos), y sin embargo, en el caso de F#
la solución es mucho más compacta y simple. Además, si se lee cada instrucción es como si se estuviera describiendo el algoritmo
(qué hacer), más que cómo hacerlo.

Sin embargo, no siempre es mejor el paradigma funcional en todos los aspectos. En cuanto a uso de memoria, la solución imperativa es más eficiente. Se había mencionado anteriormente que en esta, solo se trabaja con una sola lista y en la funcional se generan constantemente listas
 nuevas. Otra ventaja de la solución imperativa  viene dada también por el hecho de usar una sola lista. Las implementaciones
 anteriores solo dicen si existe o no solución para el problema. En caso de que se quiera hallar la distribucion del tablero que se
 encontró, en la solución imperativa solo sería necesario revisar las posiciones que quedaron guardadas en la única lista que se
 usó. Para el caso de la solución funcional, sería necesario cambiar el tipo de retorno de la función `NQueens`. Ya no sería un
 `bool`, sino también una lista con las posiciones encontradas. Esto requeriría hacer unos cuantos cambios al código, y aun así
 eso tampoco resolvería el problema de generar siempre listas nuevas, por lo que tampoco sería más eficiente con respecto a manejo de memoria (aquí
 asumimos que es una solución usando un paradigma puramente funcional, pues recordemos que F# no es un lenguajes puramente funcional y también
 soporta *features* de otros estilos de programación como valores mutables, con lo cual se podría resolver el problema de la eficiencia).

 En general, la programación funcional ofrece un alto grado de abstracción, ya que está basada en el concepto matemático y principio de función. Cuando se aplica de forma correcta, este tipo de programación crea un código muy preciso y sencillo. Por esto, hay numerosas tareas
en las que resulta muy ventajoso usarla. Sin embargo, como ya hemos visto, hay situaciones y aspectos en donde no siempre es la mejor opción
, y usando un paradigma distinto como el imperativo se logra una mejor solución.

Si al lector aún no le convence del todo las ventajas que en ciertos casos supone utilizar programación funcional, adjuntamos las palabras de Ralf Herbrich, co-líder de Microsoft Research(MSR) Applied Games Group, el cual se especializa en técnicas de machine learning:

>The first application was parsing 110GB of log data spread over 11,000 text files in over 300 directories and importing it into a SQL database.The whole application is 90 lines long (including comments!) and finished the task of parsing the source files and importing the data in under 18 hours; that works out to a staggering 10,000 log lines processed per second! Note that I have not optimized the code at all but written the application in the most obvious way. I was truly astonished as I had planned at least a week of work for both coding and running the application.
>The second application was an analysis of millions of feedbacks. We had developed the model equations and I literally just typed them in as an F# program; together with the reading-data-from-SQL-database and writing-results-to-MATLAB-data-file the F# source code is 100 lines long (including comments). Again,I was astonished by the running time; the whole processing of the millions of data items takes 10 minutes on a standard desktop machine. My C# reference application (from some earlier tasks) is almost 1,000 lines long and is no faster.The whole job from developing the model equations to having first real world data results took 2 days.