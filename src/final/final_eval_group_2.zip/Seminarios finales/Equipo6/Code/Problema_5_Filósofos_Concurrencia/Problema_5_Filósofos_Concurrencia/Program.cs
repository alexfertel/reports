﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Problema_5_Filósofos_Concurrencia
{
    class Program
    {
        static Random r = new Random();

        class Tenedor
        {
            public int n;
            public Tenedor(int n)
            {
                this.n = n;
            }
        }

        class Filosofo
        {
            Tenedor ten_izq, ten_der;
            string nombre;

            public Filosofo(Tenedor ten_izq, Tenedor ten_der, string nombre)
            {
                this.ten_izq = ten_izq;
                this.ten_der = ten_der;
                this.nombre = nombre;
            }
                        
            public void Comer_Enter()
            {
                while (true)
                {
                    Console.WriteLine("{0} {1} ", nombre, "está pensando");
                    Console.WriteLine();

                    Thread.Sleep(r.Next(1000));

                    Console.WriteLine("{0} {1} ", nombre, "quiere comer");
                    Console.WriteLine();

                    Monitor.Enter(ten_izq);
                    try
                    {
                        Console.WriteLine("{0} {1} ", nombre, "tiene el tenedor " + ten_izq.n);
                        Console.WriteLine();

                        Thread.Sleep(r.Next(1000));

                        Monitor.Enter(ten_der);
                        try
                        {
                            Console.WriteLine("{0} {1} ", nombre, "tiene el tenedor " + ten_der.n); 
                            Console.WriteLine();
                            Console.WriteLine("{0} {1} ", nombre, "está comiendo con los tenedores " + ten_izq.n + " y " + ten_der.n);
                            Console.WriteLine();

                            Thread.Sleep(r.Next(1000));
                        }

                        finally
                        {
                            Monitor.Exit(ten_der);

                            Console.WriteLine("{0} {1}", nombre + " dejó el tenedor " + ten_der.n, " libre");
                            Console.WriteLine();
                        }
                    }

                    finally
                    {
                        Monitor.Exit(ten_izq);

                        Console.WriteLine("{0} {1}", nombre + " dejó el tenedor " + ten_izq.n, " libre");
                        Console.WriteLine();
                    }
                }
            }
            
            public void Comer_TryEnter()
            {
                while (true)
                {
                    Console.WriteLine("{0} {1} ", nombre, "está pensando");
                    Console.WriteLine();

                    Thread.Sleep(r.Next(1000));

                    Console.WriteLine("{0} {1} ", nombre, "quiere comer");
                    Console.WriteLine();

                    if (Monitor.TryEnter(ten_izq, r.Next(2000)))
                    {
                        try
                        {
                            Console.WriteLine("{0} {1} ", nombre, "tiene el tenedor " + ten_izq.n);
                            Console.WriteLine();

                            Thread.Sleep(r.Next(500));

                            if (Monitor.TryEnter(ten_der, r.Next(2000)))
                            {
                                try
                                {
                                    Console.WriteLine("{0} {1} ", nombre, "tiene el tenedor " + ten_der.n);
                                    Console.WriteLine();
                                    Console.WriteLine("{0} {1} ", nombre, "está comiendo con los tenedores " + ten_izq.n + " y " + ten_der.n);
                                    Console.WriteLine();

                                    Thread.Sleep(r.Next(1000));

                                }

                                finally
                                {
                                    Monitor.Exit(ten_der);

                                    Console.WriteLine("{0} {1}", nombre + " dejó el tenedor " + ten_der.n, " libre");
                                    Console.WriteLine();
                                }
                            }
                        }

                        finally
                        {
                            Monitor.Exit(ten_izq);

                            Console.WriteLine("{0} {1}", nombre + " dejó el tenedor " + ten_izq.n, " libre");
                            Console.WriteLine();
                        }
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            Tenedor[] tenedores = new Tenedor[5] { new Tenedor(1), new Tenedor(2), new Tenedor(3), new Tenedor(4), new Tenedor(5) };

            List<Filosofo> filosofos = new List<Filosofo>();

            filosofos.Add(new Filosofo(tenedores[0], tenedores[1], "Filósofo 1"));
            filosofos.Add(new Filosofo(tenedores[1], tenedores[2], "Filósofo 2"));
            filosofos.Add(new Filosofo(tenedores[2], tenedores[3], "Filósofo 3"));
            filosofos.Add(new Filosofo(tenedores[3], tenedores[4], "Filósofo 4"));
            filosofos.Add(new Filosofo(tenedores[4], tenedores[0], "Filósofo 5"));

            List<Thread> threads = new List<Thread>();

            //Para probar Comer_Enter()
            //foreach (var item in filosofos)
            //    threads.Add(new Thread(item.Comer_Enter));

            //Para probar Comer_TryEnter
            foreach (var item in filosofos)
                threads.Add(new Thread(item.Comer_TryEnter));

            foreach (var item in threads)
                item.Start();

            foreach (var item in threads)
                item.Join();
        }
    }
}