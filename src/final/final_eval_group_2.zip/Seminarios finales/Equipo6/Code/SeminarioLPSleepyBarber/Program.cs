﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SeminarioLPSleepyBarber
{
    class Program
    {
        static void Main(string[] args)
        {
            Sleeepy_Barber barber = new Sleeepy_Barber(5);
        }
    }
    class Sleeepy_Barber
    {
        private Queue<int> clients;
        private int currentClient;
        private Semaphore semaphore;
        private int maxClients;
        private int countClient;

        public Sleeepy_Barber(int maxClients)
        {
            countClient = 0;
            this.maxClients = maxClients;
            clients = new Queue<int>();
            semaphore = new Semaphore(1, 1);
            currentClient = 0;
            Thread arrival = new Thread(() => Client_Genereator());
            Thread barber = new Thread(() => Barber());
            arrival.Start();
            barber.Start();
            arrival.Join();
            barber.Join();
        }


        private void Client_Genereator()
        {
            Random r = new Random();
            while (true)
            {
                if (r.Next(0, 2) == 1)
                {
                    currentClient++;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"Client {currentClient} arrive");
                    Console.ResetColor();

                    if (maxClients >= countClient)
                    {
                        semaphore.WaitOne();

                        countClient++;
                        clients.Enqueue(currentClient);

                        semaphore.Release();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Barbershop is full, client {currentClient} leave");
                        Console.ResetColor();
                    }
                    Thread.Sleep(r.Next(1000, 5001));
                }
            }
        }
        private void Barber()
        {
            Random r = new Random();
            while (true)
            {
                if (clients.Count > 0)
                {
                    semaphore.WaitOne();

                    countClient--;
                    int tempclient = clients.Dequeue();

                    semaphore.Release();

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Shaving to client {tempclient}");
                    Console.ResetColor();
                    Thread.Sleep(r.Next(1000, 5001));
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("Sleep");
                    Console.ResetColor();
                    Thread.Sleep(500);
                }
                

            }
        }
    }
}
