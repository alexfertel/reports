﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SynchronizationPrimitives
{
    public static class MonitorPool
    {
        //objectsOnDemand-monitor
        static Dictionary<object, MyMonitor> ObjectMonitors = new Dictionary<object, MyMonitor>();
        static Semaphore SemaphoreLock = new Semaphore(1, 1);

        //Acquires an exclusive lock on the specified object.
        public static void Enter(Object obj) 
        {
            SemaphoreLock.WaitOne();//the only share resource in this class is the dictionary
            if (!ObjectMonitors.ContainsKey(obj))
            {
                ObjectMonitors.Add(obj, new MyMonitor());//creating new monitor for this object
            }
            SemaphoreLock.Release();

            ObjectMonitors[obj].Enter();
        }

        //Releases an exclusive lock on the specified object.
        public static void Exit(Object obj) 
        {
            SemaphoreLock.WaitOne();
            if (!ObjectMonitors.ContainsKey(obj))
            {
                throw new InvalidOperationException("Can not exit a non existing monitor");
            }
            SemaphoreLock.Release();
            ObjectMonitors[obj].Exit();
        }

        //Determines whether the current thread holds the lock on the specified object.
        public static bool IsEntered(Object obj) 
        {
            SemaphoreLock.WaitOne();
            if (!ObjectMonitors.ContainsKey(obj))
            {
                throw new InvalidOperationException("There is no monitor watching over this object");
            }
            SemaphoreLock.Release();
            return ObjectMonitors[obj].CurrentThreadId == Thread.CurrentThread.ManagedThreadId;
        }

        //Notifies a thread in the waiting queue of a change in the locked object's state.
        public static void Pulse(Object obj) 
        {
            SemaphoreLock.WaitOne();
            if (!ObjectMonitors.ContainsKey(obj))
            {
                throw new InvalidOperationException("There is no monitor watching over this object");
            }
            SemaphoreLock.Release();
            ObjectMonitors[obj].Pulse();
        }

        //Notifies all waiting threads of a change in the object's state.
        public static void PulseAll(Object obj) 
        {
            SemaphoreLock.WaitOne();
            if (!ObjectMonitors.ContainsKey(obj))
            {
                throw new InvalidOperationException("There is no monitor watching over this object");
            }
            SemaphoreLock.Release();
            ObjectMonitors[obj].PulseAll();
        }

        public static void Wait(Object obj) 
        {
            SemaphoreLock.WaitOne();
            if (!ObjectMonitors.ContainsKey(obj))
            {
                throw new InvalidOperationException("There is no monitor watching over this object");
            }
            SemaphoreLock.Release();
            ObjectMonitors[obj].Wait();
        }

    }
}
