﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace SynchronizationPrimitives
{
    public class MyBarrier
    {
        public int Participants { get; private set; }
        public int Arrived { get; private set; }
        public int CurrentPhase { get; private set; }

        private Semaphore Semaphore;
        private Semaphore Lock;
        private Action<MyBarrier> Action;

        private int participantsToAdd;
        private int participantsToRemove;


        public MyBarrier(int participants)
        {
            Participants = participants;
            Arrived = 0;
            CurrentPhase = 0;
            Lock = new Semaphore(1, 1);
            Semaphore = new Semaphore(0, participants - 1);//Initilize count to 0 so no thread can pass the barrier until the last one arrives
            Action = null;
        }

        public MyBarrier(int participants, Action<MyBarrier> action)
        {
            Participants = participants;
            Arrived = 0;
            CurrentPhase = 0;
            Lock = new Semaphore(1, 1);
            Semaphore = new Semaphore(0, participants - 1);//Initilize count to 0 so no thread can pass the barrier until the last one arrives
            Action = action;
        }

        public int AddParticipant()
        {
            Lock.WaitOne();
            participantsToAdd++;
            int nextPhase = CurrentPhase + 1;
            Lock.Release();
            return nextPhase;
        }

        public int RemoveParticipant()
        {
            Lock.WaitOne();
            if (Participants + participantsToAdd - participantsToRemove == 0)
                throw new InvalidOperationException("There are no participants left for the next Barrier");
            participantsToRemove++;
            int nextPhase = CurrentPhase + 1;
            Lock.Release();
            return nextPhase;
        }

        public void SignalAndWait()
        {
            Lock.WaitOne();//This ensures exclusive privilegies over the Barrier class. No two simultaneous operations that modifie Barrie class can occur
            Arrived++;

            if (Arrived == Participants)//the last one arrived
            {
                Arrived = 0;
                UpdateParticipants();

                try
                {
                    Action?.Invoke(this);
                }
                catch (Exception e)
                {
                    CurrentPhase++;
                    Semaphore.Release(Participants - 1);//free the spaces and signaled the others so they can pass the barrier
                    Lock.Release();
                    throw e;
                }

                CurrentPhase++;
                Semaphore.Release(Participants - 1);//free the spaces and signaled the others so they can pass the barrier
                Lock.Release();
            }
            else
            {
                Lock.Release();
                Semaphore.WaitOne(); //wait for the others                   
            }
        }

        private void UpdateParticipants()
        {
            Participants += participantsToAdd - participantsToRemove;
            participantsToAdd = 0;
            participantsToRemove = 0;
        }
    }
}
