﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SynchronizationPrimitives
{
    public class MyCountdown
    {
        Semaphore _semaphore;
        Semaphore _mutex;

        int _initialCount;
        int _currentCount;
        int _waitingThreads;

        public int InitialCount { get { return _initialCount; } }
        public int CurrentCount { get { return _currentCount; } }
        public bool IsSet { get { return _currentCount == 0; } }


        public MyCountdown(int initial)
        {
            _semaphore = new Semaphore(0, int.MaxValue);
            _mutex = new Semaphore(1, 1);
            _initialCount = _currentCount = initial;
            _waitingThreads = 0;
        }

        public void AddCount()
        {
            _mutex.WaitOne();
            _currentCount++;
            _mutex.Release();
        }

        public void AddCount(int count)
        {
            _mutex.WaitOne();
            _currentCount += count;
            _mutex.Release();
        }

        public void Reset()
        {
            _mutex = new Semaphore(1, 1);
            _semaphore = new Semaphore(0, int.MaxValue);
            _currentCount = _initialCount;
            _waitingThreads = 0;
        }

        public void Reset(int count)
        {
            _mutex = new Semaphore(1, 1);
            _semaphore = new Semaphore(0, int.MaxValue);
            _initialCount = _currentCount = count;
            _waitingThreads = 0;
        }

        public void Signal()
        {
            _mutex.WaitOne();

            if (_currentCount > 0)
                _currentCount--;

            if (_currentCount == 0)
            {
                _semaphore.Release(_waitingThreads);
                _waitingThreads = 0;
            }

            _mutex.Release();
        }

        public void Signal(int count)
        {
            _mutex.WaitOne();

            if (_currentCount > count)
                _currentCount -= count;

            if (_currentCount == 0)
            {
                _semaphore.Release(_waitingThreads);
                _waitingThreads = 0;
            }

            _mutex.Release();
        }

        public void Wait()
        {
            _mutex.WaitOne();
            if (_currentCount > 0)
            {
                _waitingThreads++;
                _mutex.Release();
                _semaphore.WaitOne();
            }
            else
                _mutex.Release();
        }
    }
}
