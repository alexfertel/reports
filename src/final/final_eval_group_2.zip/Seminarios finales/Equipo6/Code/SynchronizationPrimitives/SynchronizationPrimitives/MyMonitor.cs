﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SynchronizationPrimitives
{
    class MyMonitor
    {
        public int CurrentThreadId { get; private set; }
        private Semaphore semaphoreLock;//the key for enter exit, the one that allows just one thread to manipulate the main object
        private Semaphore waitingThreads;// simulates the queue of threads that are waiting for a pulse signal to restore his execution
        private Semaphore waitingQueueSemaphore;//a key to control access over the waiting list
        private int waitingThreadsNum;


        public MyMonitor()
        {
            CurrentThreadId = -1;
            waitingQueueSemaphore = new Semaphore(1, 1);
            semaphoreLock = new Semaphore(1, 1);
            waitingThreads = new Semaphore(0, int.MaxValue);
            waitingThreadsNum = 0;
        }
       
        public void Enter() 
        {
            semaphoreLock.WaitOne();
            CurrentThreadId = Thread.CurrentThread.ManagedThreadId;
        }
       
        public void Wait() 
        {
            Exit();
            waitingQueueSemaphore.WaitOne();
            waitingThreadsNum++;
            waitingQueueSemaphore.Release();
            waitingThreads.WaitOne();
            Enter();
        }
        
        public void Pulse() 
        {
            waitingQueueSemaphore.WaitOne();
            waitingThreads.Release();
            if(waitingThreadsNum > 0)
                waitingThreadsNum--;
            waitingQueueSemaphore.Release();
        }
        
        public void PulseAll() 
        {
            waitingQueueSemaphore.WaitOne();
            waitingThreads.Release(waitingThreadsNum);
            waitingThreadsNum = 0;
            waitingQueueSemaphore.Release();
        }
        
        public void Exit()
        {
            CurrentThreadId = -1;
            semaphoreLock.Release();
        }
    }
}
