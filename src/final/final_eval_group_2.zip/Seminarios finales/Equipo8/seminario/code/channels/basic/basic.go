/*
Cuando la funcion `main` ejecuta `<-c`, esta esperará a que un valor
sea enviado por el canal.

Cuando la funcion `greet` ejecuta `c <- value`, esta espera a que el
receptor del otro lado este listo.

Un emisor y un receptor deben ambos estar listos para jugar su rol en
la comunicación. De lo contrario se espera a que ambos lo estén.

De esta manera los canales comunican y sincronizan.
*/
package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	// Canal de string.
	c := make(chan string)

	go greet("Joe", c)

	for i := 0; i < 5; i++ {
		// Recibir de un canal - se bloquea esperando recibir.
		// Expresion de recepción `<-c` se utiliza como valor.
		fmt.Printf("You say: %q\n", <-c)
	}

	fmt.Println("I say: Hello to you too.")
}

func greet(name string, c chan string) {
	for i := 0; ; i++ {
		// Enviar por el canal.
		// El valor a ser enviado puede ser cualquiera que se ajuste al tipo del canal.
		c <- fmt.Sprintf("Hello %s - %d", name, i)

		// La operación de envio no retorna hasta que `main` no termine de recibir.
		time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
	}
}
