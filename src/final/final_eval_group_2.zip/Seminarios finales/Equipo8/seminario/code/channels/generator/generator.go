/*
Generador: Funcion que retorna un canal

La función `greet` se comporta como un servicio, permitiendonos mayor
encapsulamiento.

La funcion `greet` retorna un canal que nos permite comunicarnos con el
servicio que ella provee.

Podemos por supuesto tener mas de una instancia de dicho servicio.
*/
package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	joe := greet("Joe") // Funcion que retorna un canal
	ann := greet("Ann") // Funcion que retorna un canal

	for i := 0; i < 5; i++ {
		fmt.Println(<-joe) // Joe y Ann se bloquean entre ellos
		fmt.Println(<-ann) // mientras se espera recibir un mensaje.
	}

	fmt.Println("I'm leaving.")
}

func greet(name string) <-chan string { // Retorna canal de solo recepción (<-) de strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			c <- fmt.Sprintf("I'm %s - %d", name, i)
			time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
		}
	}()

	return c // Retorna el canal.
}
