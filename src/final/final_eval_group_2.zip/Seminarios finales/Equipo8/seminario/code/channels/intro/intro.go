func make() {
	// declarando e inicializando
	var c chan int
	c = make(chan int)

	// equivalente a la variante anterior
	c := make(chan int)
}

func send(c chan int) {
	// enviando a traves de un canal
	c <- 1
}

func receive(c chan int) {
	// recibiendo a traves de un canal
	value = <-c
}