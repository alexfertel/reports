/*
Multiplexing: Permitir hablar a cualquiera que este listo.

La funcion `fanIn` se pone frente a los otros canales. Las gorrutinas que
esten listas para hablar pueden hacerlo independientemente, sin ser bloqueadas
por otras gorrutinas. El canal `FanIn` recibe todos lo mensajes a ser procesados.

Desacopla la ejecucion de diferentes gorrutinas.

Joe ---
       \
        ----- FanIn --- Mensajes independientes mostrados
       /
Ann ---
*/

package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	c := fanIn(greet("Joe"), greet("Ann"))

	for i := 0; i < 10; i++ {
		fmt.Println(<-c) // Muestra el mensaje recibido en el canal FanIn.
	}

	fmt.Println("I'm leaving.")
}

func fanIn(input1, input2 <-chan string) <-chan string {
	c := make(chan string) // El canal FanIn

	// Esta gorrutina recibe los mensajes de Joe
	go func() {
		for {
			// Escribe el mensaje al canal FanIn. Llamado que bloquea.
			c <- <-input1
		}
	}()

	// Esta gorrutina recibe los mensajes de Ann
	go func() {
		for {
			// Escribe el mensaje al canal FanIn. Llamado que bloquea.
			c <- <-input2
		}
	}()

	return c
}

func greet(name string) <-chan string { // Retorna canal de solo recepción (<-) de strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			c <- fmt.Sprintf("I'm %s - %d", name, i)
			time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
		}
	}()

	return c // Retorna el canal.
}
