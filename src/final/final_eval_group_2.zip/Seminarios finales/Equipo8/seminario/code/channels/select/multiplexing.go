package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	c := fanIn(greet("Joe"), greet("Ann"))

	for i := 0; i < 10; i++ {
		fmt.Println(<-c) // Muestra el mensaje recibido en el canal FanIn.
	}

	fmt.Println("I'm leaving.")
}

func fanIn(input1, input2 <-chan string) <-chan string {
	c := make(chan string) // El canal FanIn

	// Ahora utilizando select y solo una gorrutina
	go func() {
		for {
			select {
			case s := <-input1:
				c <- s

			case s := <-input2:
				c <- s
			}
		}
	}()

	return c
}

func greet(name string) <-chan string { // Retorna canal de solo recepción (<-) de strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			c <- fmt.Sprintf("I'm %s - %d", name, i)
			time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
		}
	}()

	return c // Retorna el canal.
}
