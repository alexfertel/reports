/*
Recibir por el canal de quit

¿Que tal si la gorrutina que se está tratando de terminar no
termina inmediatamente al enviarle la señal? Es posible que la
gorrutina tenga algun tipo de limpieza que hacer antes de terminar
(quizas eliminar algun tipo de archivos temporales).

Para resolver este problema se espera a recibir un valor a traves del
propio canal quit por el cual se envio la señal de finalización, como
señal de que ya la gorrutina terminó su ejecución.
*/
package main

import (
	"fmt"
	"math/rand"
)

func main() {
	quit := make(chan bool)
	c := greet("Joe", quit)

	for i := rand.Intn(10); i >= 0; i-- {
		fmt.Println(<-c)
	}

	quit <- true
	<-quit
	fmt.Println("I'm leaving.")
}

func greet(msg string, quit chan bool) <-chan string {
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			select {
			case c <- fmt.Sprintf("I'm %s - %d", msg, i):
				// No hacer nada
			case <-quit:
				cleanup()
				fmt.Println("Quiting")
				quit <- true
				return
			}
		}
	}()

	return c // Retorna el canal.
}

func cleanup() {
	fmt.Println("Cleaned Up")
}
