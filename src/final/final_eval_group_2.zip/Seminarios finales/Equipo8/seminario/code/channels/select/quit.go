/*
Quit

Es posible darle la vuelta al ejemplo y decirle a Joe que pare
de ejecutarse en cualquier momento que deseemos.
*/
package main

import (
	"fmt"
	"math/rand"
)

func main() {
	quit := make(chan bool)
	c := greet("Joe", quit)

	for i := rand.Intn(10); i >= 0; i-- {
		fmt.Println(<-c)
	}

	quit <- true
	fmt.Println("I'm leaving.")
}

func greet(msg string, quit chan bool) <-chan string { // Returns receive-only (<-) channel of strings.
	c := make(chan string)

	// `func() {...}` es un literal de funcion.
	go func() { // Lanza la gorrutina desde dentro de la función.
		for i := 0; ; i++ {
			select {
			case c <- fmt.Sprintf("I'm %s - %d", msg, i):
				// No hacer nada
			case <-quit:
				fmt.Println("Quiting")
				return
			}
		}
	}()

	return c // Retorna el canal.
}
