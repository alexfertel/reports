package main
 
import (
    "hash/fnv"
    "log"
    "math/rand"
    "os"
    "time"
)
 
// Number of philosophers is simply the length of this list.
// It is not otherwise fixed in the program.
var ph = []string{"Aristotle", "Kant", "Spinoza", "Marx", "Russell"}
 
const hunger = 3                // cantidad de veces q el filosofo come
const think = time.Second / 100 // tiempo de pensar
const eat = time.Second / 100   // tiempo de comer
 
var fmt = log.New(os.Stdout, "", 0) 
 
var done = make(chan bool)
 
// utiliza channels para sincronizacion
// los canales enviados son los "forks."(tenedores)
type fork byte
 
 //Un objeto tenedor en el programa modela un tenedor en la simulacion
 //por cada fork(tenedor) se hace un canal(channel) separado, por esa razon los channel son buffered con capacidad = 1

// Goroutine para las acciones de los filosofos.  Una instancia es ejecutada por cada filosofo
// las instancias se ejecutan de forma concurrente.
func philosopher(phName string,
    dominantHand, otherHand chan fork, done chan bool) {
    fmt.Println(phName, "seated")
    h := fnv.New64a()
    h.Write([]byte(phName))
    rg := rand.New(rand.NewSource(int64(h.Sum64())))
    // funcion para hacer dormir la ejecucion del codigo mientras se realizan operaciones en el background
    rSleep := func(t time.Duration) {
        time.Sleep(t/2 + time.Duration(rg.Int63n(int64(t))))
    }
    for h := hunger; h > 0; h-- {
        fmt.Println(phName, "hungry")
        <-dominantHand // coger los tenedores
        <-otherHand
        fmt.Println(phName, "eating")
        rSleep(eat)
        dominantHand <- 'f' // soltar los tenedores
        otherHand <- 'f'
        fmt.Println(phName, "thinking")
        rSleep(think)
    }
    fmt.Println(phName, "satisfied")
    done <- true
    fmt.Println(phName, "left the table")
}
 
func main() {
    fmt.Println("table empty")
    // crear los canales de los tenedores y los goroutines de los filosofos,
    // cada filosofo obtiene los canales(tenedores) correspondientes
    place0 := make(chan fork, 1)
    place0 <- 'f' 
    placeLeft := place0
    for i := 1; i < len(ph); i++ {
        placeRight := make(chan fork, 1)
        placeRight <- 'f'
        go philosopher(ph[i], placeLeft, placeRight, done)
        placeLeft = placeRight
    }

    //Hacer q un filosofo sea zurdo, revirtiendo los lugares de los tenedores
    //que se le da a la mano dominante del filosofo. esto logra precedencia aciclica previendo 'deadlock'
    go philosopher(ph[0], place0, placeLeft, done)
    // they are all now busy eating
    for range ph {
        <-done // wait for philosphers to finish
    }
    fmt.Println("table empty")
}