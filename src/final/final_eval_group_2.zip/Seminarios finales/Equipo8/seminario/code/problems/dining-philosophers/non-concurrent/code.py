import random
import time

forks_free:[]bool=[]
class Philosopher():
    
    running = False
    ate = False
    global forks_free
    
    def init(self, xname,forkOnLeft,forkOnRight):
        self.name = xname
        self.forkOnLeft = forkOnLeft
        self.forkOnRight = forkOnRight
        
    def start(self):
        if forks_free[forkOnLeft] and forks_free[forkOnRight] and not ate:
            forks_free[forkOnLeft] = forks_free[forkOnRight] = True
            running = True
            
    def dine(self):
        if running:
            print('%s starts eating'%self.name)
            time.sleep(random.uniform(1,10))
            print('%s finishes eating and leaves to think.' %self.name)
            forks_free[forkOnLeft] = forks_free[forkOnRight] = False
            ate = True

def DiningPhilosophers():
    forks_free = [False for i in range(5)]
    philosopherNames = ('Aristotle', 'Kant', 'Buddha', 'Marx', 'Russel')
    philosophers =[ Philosopher(philosopherNames[i], i%5, (i+1)%5) for i in range(5)]
    
    random.seed(507129)
    all_ate = False
    while not all_ate:
        for p in philosophers : p.start()
        for p in philosphers : p.dine()
        for p in philosopher:
            if  not p.ate
                break
        else:
            all_ate = True

DiningPhilosophers()