package main

import (
	"fmt" 
	"math/rand"
	"time"
	"strconv"
)

//Queue is ...
type Queue struct {
	maxsize int
	queue chan *int
	total int
}

func (q *Queue) producer() {

	for true {
		item := rand.Intn(10)

		select {
			case q.queue <- &item:
				q.total++
				fmt.Println("Produced " + strconv.Itoa(item))
				timeToSleep := rand.Intn(3)
				time.Sleep(time.Duration(timeToSleep) * time.Second)
		default:
		}
	}
}

func (q *Queue) consumer() {

	for true {

		var item *int
		select {
			case item = <- q.queue: 
				fmt.Println("Cosumed " + strconv.Itoa(*item))
				timeToSleep := rand.Intn(3)
				time.Sleep(time.Duration(timeToSleep) * time.Second)
		default:
		}
	}
}

func main()  {
	queue := Queue{
		queue: make(chan *int, 3),
		total: 0,
	}
	go queue.producer()
	go queue.consumer()
	for queue.total < 15 {
	}
}