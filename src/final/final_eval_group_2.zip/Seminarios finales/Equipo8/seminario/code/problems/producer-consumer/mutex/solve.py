import time
import queue
import random
from threading import Thread, Lock

mutex = Lock()
queue = queue.Queue(maxsize=10)

def producer():
    while True:
        if not queue.full():
            mutex.acquire()
            item = random.randint(1, 10)
            queue.put(item)

            print("Produced: " + str(item))

            time_to_sleep = random.randint(1, 3)
            time.sleep(time_to_sleep)
            mutex.release()

def consumer():
    while True:
        if not queue.empty():
            mutex.acquire()
            item = queue.get()

            print("Consumed: " + str(item))

            time_to_sleep = random.randint(1, 3)
            time.sleep(time_to_sleep)
            mutex.release()


producer = Thread(target = producer)
consumer = Thread(target = consumer)

producer.start()
consumer.start()