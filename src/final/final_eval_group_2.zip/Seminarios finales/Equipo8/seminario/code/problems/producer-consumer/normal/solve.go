package main

import (
	"fmt" 
	"math/rand"
	"time"
	"strconv"
)

func producer(queue []int, maxsize int) []int {

	if len(queue) < maxsize {
		item := rand.Intn(10)
		queue = append(queue, item)
		fmt.Println("Produced " + strconv.Itoa(item))
	
		timeToSleep := rand.Intn(3)
		time.Sleep(time.Duration(timeToSleep) * time.Second)
	}

	return queue
}

func consumer(queue []int, maxsize int) []int {

	if len(queue) > 0 {
		item := queue[0]
		queue = queue[1:]
		fmt.Println("Cosumed " + strconv.Itoa(item))
	
		timeToSleep := rand.Intn(3)
		time.Sleep(time.Duration(timeToSleep) * time.Second)
	}

	return queue
}

func main()  {
	var queue []int
	for true {
		r := rand.Intn(2)
		if r == 0 {
			queue = producer(queue, 3)
		} else {
			queue = consumer(queue, 3)
		}
	}
}