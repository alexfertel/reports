package main

import (
	"fmt" 
	"time"
	"math/rand"
	"sync"
	"context"
)

// Event is a communication primitive allowing for multiple goroutines to wait
// on an event to be set.
type Event struct {
	next chan chan struct{}
}

// New creates a new event instance.
func New() *Event {
	next := make(chan chan struct{}, 1)
	next <- make(chan struct{})
	return &Event{next: next}
}

// IsSet indicates whether an event is set or not.
func (r *Event) IsSet() bool {
	event := <-r.next
	r.next <- event
	return event == nil
}

// Set changes the internal state of an event to true.
func (r *Event) Set() {
	event := <-r.next
	if event != nil {
		close(event)
		event = nil
	}
	r.next <- event
}

// Clear resets the internal event state back to false.
func (r *Event) Clear() {
	event := <-r.next
	if event == nil {
		event = make(chan struct{})
	}
	r.next <- event
}

// Wait blocks until the event is set to true. If the event is already set,
// returns immediately. Otherwise blocks until another goroutine sets the event.
func (r *Event) Wait(ctx context.Context) error {
	event := <-r.next
	r.next <- event
	if event != nil {
		if ctx == nil {
			ctx = context.Background()
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-event:
		}
	}
	return nil
}



// Barbershop is ...
type Barbershop struct {
	mutex sync.Mutex
	len int
	barber bool
	chairs []string
	event *Event
}

func (b *Barbershop) barberGoToWork()  {
	for true {
		b.mutex.Lock()
		if b.clientAvaliable() {
			first := b.vocateChair()
			b.mutex.Unlock()
			b.event.Clear()
			fmt.Println(first + " is having a haircut")
			r := rand.Intn(3) + 2
			time.Sleep(time.Duration(r) * time.Second)
			fmt.Println(first + " is done")
		} else {
			b.mutex.Unlock()
			fmt.Println("Aaah, all done, going to sleep")
			b.event.Wait(nil)
			fmt.Println("Barber woke up")
		}
	}
}

func (b *Barbershop) chairAvaliable() bool {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			return true
		}
	}
	return false
}
func (b *Barbershop) clientAvaliable() bool {
	return b.chairs[0] != " "
}
func (b *Barbershop) occupyChair(name string) {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			b.chairs[i] = name
			return
		}
	}
}
func (b *Barbershop) vocateChair() string {
	first := b.chairs[0]
	for i:= 0; i < b.len - 1; i++ {
		b.chairs[i] = b.chairs[i + 1] 
	}
	b.chairs[b.len - 1] = " "
	return first
}
func (b *Barbershop) newClient(name string) {
	b.mutex.Lock()
	fmt.Println(name + " entered the barbershop.")  
	if b.chairAvaliable() {
		fmt.Println("Waiting room is avaliable, " + name + " sat down.")
		b.occupyChair(name)
		b.mutex.Unlock()
		b.event.Set()
	} else {
		fmt.Println("Waiting room is full, " + name + " leaved.")
		b.mutex.Unlock()
	}
}

func (b *Barbershop) simulation(clients []string)  {
	go b.barberGoToWork()
	for len(clients) > 0 {
		first := clients[len(clients) - 1]
		clients = clients[:len(clients) - 1]
		b.newClient(first)
		r := rand.Intn(3) + 2
		time.Sleep(time.Duration(r) * time.Second)
	}
}

func main() {	

	b := Barbershop {
		len: 5,
		barber: false,
		chairs: []string{" ", " ", " ", " "," "},
		event: New(),
	}
	clients := []string{"Bratt","Ana","Iris","Axel","Andrea","Edgar","Maria","Sonia","Olga","Bernard","Berkis"}      
	b.simulation(clients)

}