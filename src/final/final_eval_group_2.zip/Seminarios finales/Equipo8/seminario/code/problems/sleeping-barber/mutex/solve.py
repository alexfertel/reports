

import time, random
from threading import Thread, Lock, Event

mutex = Lock()

class Barber:
	barberWorkingEvent = Event()

	#El barbero esta durmiendo
	def sleep(self):
		self.barberWorkingEvent.wait()

	#El barbero se despierta
	def wakeUp(self):
		self.barberWorkingEvent.set()

	#El baebro esta trabajando
	def cutHair(self, name):
		self.barberWorkingEvent.clear()
		print(name + ' is having a haircut')
		time.sleep(random.randrange(2,5))
		print(name + ' is done')

class Barbershop:
	def __init__(self, n):
		self.len = n
		self.barber = Barber()
		self.chairs = ['']*n

	#Se crea un hilo para los eventos del barbero
	def open(self):
		workingThread = Thread(target = self.barberGoToWork)
		workingThread.start()
	#Se ejecuta el hilo
	def barberGoToWork(self):
		while True:
			#Se cierra para aceder al recurso compartido
			mutex.acquire()
			if self.clientAvaliable():
				first = self.vocateChair()
				mutex.release()
				#Se termina de usar el recurso compartido
				self.barber.cutHair(first)
			else:
				mutex.release()
				#Se termina de usar el recurso compartido
				print('Aaah, all done, going to sleep')
				self.barber.sleep()
				print('Barber woke up')	

	def chairAvailable(self):
		return len(list(filter(lambda chair: chair == '', self.chairs))) > 0    
	def clientAvaliable(self):
		return self.chairs[0] != ''    
	def occupyChair(self, name):
		self.chairs[self.chairs.index('')] = name
	def vocateChair(self):
	    first = self.chairs[0]
	    for i in range(self.len - 1):
	        self.chairs[i] = self.chairs[i + 1]
	    self.chairs[self.len - 1] = ''
	    return first

	def newClient(self, name):
		#Se cierra para aceder al recurso compartido
		mutex.acquire()
		print(name + ' entered the barbershop')
		if self.chairAvailable():
			print('Waiting room is avaliable, ' + name + ' sat down.')
			self.occupyChair(name)
			mutex.release()
			#Se termina de usar el recurso compartido
			self.barber.wakeUp()
		else:
			print('Waiting room is full, ' + name + ' leaved.')
			mutex.release()
			#Se termina de usar el recurso compartido
  
	def simulation(self, cleints):
		self.open()
		while len(cleints) > 0:
			self.newClient(clients.pop())
			time.sleep(random.randrange(2,5))

clients = ['Bratt','Ana','Iris','Axel','Andrea','Edgar','Maria','Sonia','Olga','Bernard','Berkis']      
b = Barbershop(5)
b.simulation(clients)


