package main
import (
	"fmt" 
	"math/rand"
	"time"
)
// Barbershop is ...
type Barbershop struct {
	len int
	barber bool
	chairs []string
	current string
}
//El cliente puede sentarse a esperar
func (b *Barbershop) chairAvaliable() bool {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			return true
		}
	}
	return false
}
//Existen clientes para pelar
func (b *Barbershop) clientAvaliable() bool {
	return b.chairs[0] != " "
}

//El cliente se sienta a esperar
func (b *Barbershop) occupyChair(name string) {
	for i := 0; i < b.len; i++ {
		if b.chairs[i] == " " {
			b.chairs[i] = name
			return
		}
	}
}
//El cliente pasa a pelarse
func (b *Barbershop) vocateChair() string {
	first := b.chairs[0]
	for i:= 0; i < b.len - 1; i++ {
		b.chairs[i] = b.chairs[i + 1] 
	}
	b.chairs[b.len - 1] = " "
	return first
}

func (b *Barbershop) newClient(name string) {
	fmt.Println(name + " entered the barbershop.")
    if b.barber {
		fmt.Println("Barber is busy.")
		if b.chairAvaliable() {
			fmt.Println("Waiting room is avaliable, " + name + " sat down.")
			b.occupyChair(name)
		} else {
			fmt.Println("Waiting room is full, " + name + " leaved.")
		}
	} else {
		fmt.Println("Barber is avaliable.")
		fmt.Println(name + " is having a haircut.")
		b.current = name
		b.barber = true
	}
}
func (b *Barbershop) finishHaircut() {
	fmt.Println("Barber finish the " + b.current + "'s haircut.")
	if b.clientAvaliable() {
		first := b.vocateChair()
		b.current = first
		fmt.Println(first + " is having a haircut.")
	} else {
		b.barber = false
	}
}


func (b *Barbershop) simulation(clients []string)  {
	for len(clients) > 0 {
		rand.Seed(time.Now().UnixNano())
		if !b.barber {
			r := rand.Intn(2)
			if r == 0 {
				first := clients[len(clients) - 1]
				clients = clients[:len(clients) - 1]
				b.newClient(first)
			} else {
				continue	
			}
		} else {
			r := rand.Intn(3)
			if r == 0 {
				first := clients[len(clients) - 1]
				clients = clients[:len(clients) - 1]
				b.newClient(first)
			} 
			if r == 1 {
				b.finishHaircut()	
			} else {
				continue
			}
		}
		time.Sleep(3 * time.Second)
	}
	fmt.Println("Aaah, all done, going to sleep")
}

func main() {	
	b := Barbershop {
		len: 5,
		barber: false,
		chairs: []string{" ", " ", " ", " "," "},
	}
	clients := []string{"Bratt","Ana","Iris","Axel","Andrea","Edgar","Maria","Sonia",
						"Olga","Bernard","Berkis"}      
	b.simulation(clients)

}