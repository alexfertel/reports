
import time, random

class Barbershop:
    def __init__(self, n):
        self.len = n
        self.barber = 0
        self.chairs = ['']*n
        self.current = ''
    
    #El cliente puede sentarse a esperar
    def chairAvailable(self):
        return len(list(filter(lambda chair: chair == '', self.chairs))) > 0
    
    #Existen clientes para pelar
    def clientAvaliable(self):
        return self.chairs[0] != ''
    
    #El cliente se sienta a esperar
    def occupyChair(self, name):
        self.chairs[self.chairs.index('')] = name

    #El cliente pasa a pelarse
    def vocateChair(self):
        first = self.chairs[0]
        for i in range(self.len - 1):
            self.chairs[i] = self.chairs[i + 1]
        self.chairs[self.len - 1] = ''
        return first
    
    def newClient(self, name):
        print(name + ' entered the barbershop.')
        if self.barber:
            print('Barber is busy')
            if self.chairAvailable():
                print('Waiting room is avaliable, ' + name + ' sat down.')
                self.occupyChair(name)
            else:
                print('Waiting room is full, ' + name + ' leaved.')
                return
        else:
            print('Barber is avaliable.')
            print(name + ' is having a haircut.')
            self.current = name
            self.barber = 1
    
    def finishHaircut(self):
        print('Barber finish the '+  self.current + 's haircut.')
        if self.clientAvaliable():
            first = self.vocateChair()
            self.current = first
            print(first + ' is having a haircut.')
        else:
            self.barber = 0

    def simulation(self, clients):
        while len(clients) > 0:

            if self.barber == 0:
                r = random.randrange(0,2)
                if r == 0:
                    self.newClient(clients.pop())
                else:
                    continue
            else:
                r = random.randrange(0,3)
                if r == 0:
                    self.newClient(clients.pop())
                if r == 1:
                    self.finishHaircut()
                else:
                    continue
            time.sleep(3)

clients = ['Bratt','Ana','Iris','Axel','Andrea','Edgar','Maria','Sonia','Olga','Bernard','Berkis']      
b = Barbershop(5)
b.simulation(clients)
