﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Bag
{
    public class SafeCollection<T> : ICollection<T>
    {
        private List<T> _collection;
        private Mutex _mutex;
        public int Count => GetCount();
        public bool IsReadOnly => false;

        public SafeCollection()
        {
            this._mutex = new Mutex();
            this._collection = new List<T>();
        }

        public void Add(T item)
        {
            _mutex.WaitOne();
            _collection.Add(item);
            _mutex.ReleaseMutex();
        }

        public void Clear()
        {
            _mutex.WaitOne();
            _collection.Clear();
            _mutex.ReleaseMutex();
        }

        public bool Contains(T item)
        {
            _mutex.WaitOne();
            var contains = _collection.Contains(item);
            _mutex.ReleaseMutex();
            return contains;
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            _mutex.WaitOne();
            _collection.CopyTo(array, arrayIndex);
            _mutex.ReleaseMutex();
        }

        public IEnumerator<T> GetEnumerator()
        {
            _mutex.WaitOne();
            var enumerator = _collection.GetEnumerator();
            _mutex.ReleaseMutex();
            return enumerator;
        }

        public bool Remove(T item)
        {
            _mutex.WaitOne();
            bool removed = _collection.Remove(item);
            _mutex.ReleaseMutex();
            return removed;
        }

        public int GetCount()
        {
            _mutex.WaitOne();
            int count = _collection.Count;
            _mutex.ReleaseMutex();
            return count;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            _mutex.WaitOne();
            var enumerator = _collection.GetEnumerator();
            _mutex.ReleaseMutex();
            return enumerator;
        }
    }
}
