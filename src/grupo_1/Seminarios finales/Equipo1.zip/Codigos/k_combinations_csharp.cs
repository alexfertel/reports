﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ConsoleApp2
{
    internal static class Program
    {
        private static List<List<T>> Combinations<T>(int k, List<T> items)
        {
            if (k == 0)
                return new List<List<T>> {new List<T>()};

            if (!items.Any())
                return new List<List<T>>();
            
            var (first, rest) = (items.First(), items.Skip(1).ToList());
            return Combinations(k - 1, rest).Select(x => x.Prepend(first).ToList()).
                Concat(Combinations(k, rest)).ToList();
        }

        private static List<List<T>> CombinationsNonCompact<T>(int k, List<T> items)
        {
            if (k == 0)
                return new List<List<T>> {new List<T>()};

            if (!items.Any())
                return new List<List<T>>();

            var first = items[0];
            var rest = items.GetRange(1, items.Count - 1);

            var l1 = CombinationsNonCompact(k - 1, rest);
            var l2 = CombinationsNonCompact(k, rest);

            foreach (var x in l1)
                x.Insert(0, first);

            var result = new List<List<T>>();
            foreach (var x in l1) 
                result.Add(x);
            
            foreach (var x in l2) 
                result.Add(x);
            
            return result;
        }

        private static void Main(string[] args)
        {
            var numbers = new int[4];
            for (var i = 0; i < numbers.Length; i++) numbers[i] = i + 1;
            
            var sw = new Stopwatch();
            sw.Start();
            var combs = Combinations(2, numbers.ToList());
            sw.Stop();
            Console.WriteLine("Combinations in " + sw.ElapsedMilliseconds + " ms");
            foreach (var subset in combs) Console.Write(IterToString(subset) + " ");
        }

        private static string IterToString<T>(IEnumerable<T> enumerable)
        {
            var e = enumerable as T[] ?? enumerable.ToArray();
            return e.Any()
                ? e.Aggregate("[", (current, x) => current + (x + ", "),
                    (current) => current.Substring(0, current.Length - 2)) + "]"
                : "[]";
        }
    }
}