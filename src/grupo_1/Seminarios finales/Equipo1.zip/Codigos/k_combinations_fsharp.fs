﻿// Learn more about F# at http://fsharp.org

open System.Diagnostics

[<EntryPoint>]
let main argv =
    let rec combinations k l = 
        match k, l with
        | 0, _ -> [[]]
        | _, [] -> []
        | k, (x::xs) -> List.map ((@) [x]) (combinations (k - 1) xs) @ combinations k xs

    let sw = Stopwatch()
    sw.Start()    
    let k_combinations = combinations 2 [1..5]   
    sw.Stop()
    printfn "Combinations in %d ms" sw.ElapsedMilliseconds
    printfn "%A" k_combinations
    0
