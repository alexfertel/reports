def componentized(cls):
    class wrapper:
        def __init__(self,*args):
            self.instance = cls(*args)
            self.components = []

            for comp in cls.__dict__:
                if type(cls.__dict__[comp]) == component:
                    self.components.append(comp)


        def __getattr__(self,attribute):
            if len(attribute) == 1:
                return getattr(self.instance,attribute)            
            else:                
                if self.NotComponent(attribute):
                    raise Exception("Atributo Invalido")
                return tuple(getattr(self.instance,comp) for comp in attribute)
        

        def __setattr__(self,attribute,value):
            if attribute == 'instance' or attribute == 'components':
                self.__dict__[attribute] = value
            else:
                if self.RepeatComp(attribute):
                    raise Exception("Una componente no se puede repetir en una asignacion multiple")

                if isinstance(value, tuple):
                    if len(attribute) != len(value):
                        raise Exception("No coinciden la cantidad de componentes con la cantidad de valores")
                    if(self.NotComponent(attribute)):
                        raise Exception("Atributo Invalido")
                    for comp, val in zip(attribute, value):
                        setattr(self.instance, comp, val)
                else:                    
                    
                    if self.NotComponent(attribute):
                        raise Exception("Atributo Invalido")

                    for comp in attribute:
                        setattr(self.instance, comp, value)
        

        def RepeatComp(self,attribute):
            for i in range(0,len(attribute)):
                for j in range(i + 1,len(attribute)):
                    if attribute[i] == attribute[j]:
                        return True
            return False


        def NotComponent(self,attribute):
            for comp in attribute:
                if comp not in self.components:
                    return True
            return False
    return wrapper


class component():
    def __init__(self,tipo):
        self.type = tipo
        self.value = {}    

    def __get__(self,instance,owner):
        return self.value[instance]    

    def __set__(self,instance,value):
        if self.type != type(value):
            raise Exception("El tipo de componente tiene que ser " + str(self.type))
        else:
            self.value[instance] = value

@componentized
class Vector2D:
    x = component(float)
    y = component(float)
    def __init__(self,x,y):
        self.x = x
        self.y = y


@componentized
class Color:
	r = component(str)
	g = component(str)
	b = component(str)
	def __init__(self, r, g, b):
		self.r = r
		self.g = g
		self.b = b



def VectorMain():
    v = Vector2D(1.0,4.0)

    #get
    print(v.x)
    print(v.y)
    print(v.xy)
    print(v.xx)

    #set
    #v.xx = (3.0,2.0) #Exception: Una componente no se puede repetir en una asignacion multiple
    #v.xy = (1.0,2.0,3.0) #Exception: No coinciden la cantidad de componentes con la cantidad de valores 
    #v.xz = (4.0,5.0) #Exception: Atributo invalido
    #v.x = "texto" #Exception: El tipo de componente tiene que ser float
    v.xy = (3.0, 5.0)
    print(v.xy)
    v.xy = v.yx
    print(v.xy)

    v.x = 10.0 #Se le asigna el valor 10 a x
    print(v.xy)

    v.xy = 18.0 #Se le asigna el valor 18 a x e y
    print(v.xy)

def ColorMain():
    c = Color("rojo","gris","blanco")

    print(c.rgb)

    c.rgb=c.bgr
    print(c.rgb)

    c.rgb = c.ggg	
    print(c.rgb)
    
    #c.r = 10 #Exception: El tipo de componente tiene que ser str
    #print(c.r)

if __name__ == "__main__":
    
    VectorMain()
    
    ColorMain()
        