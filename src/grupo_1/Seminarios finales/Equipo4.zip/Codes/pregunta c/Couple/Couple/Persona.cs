﻿using System;
using System.Diagnostics.Contracts;

namespace Couple
{
    class Persona
    {
        public Persona(string nombre)
        {
            Contract.Requires(!string.IsNullOrEmpty(nombre), "Debe especificar un nombre no vacío.");
            Nombre = nombre;
        }

        public string Nombre { get; private set; }

        private Persona _pareja { get; set; }

        public Persona Pareja
        {
            get
            {
                return _pareja;
            }
            private set
            {
                Contract.Requires(value == null || value.Pareja == this || value.Pareja == null, "Pareja no valida para esta persona");
                this._pareja = value;
            }
        }

        public void Emparejar(Persona persona)
        {
            if (Pareja != null)
            {
                Desemparejar();
            }

            if (persona.Pareja != null)
            {
                persona.Desemparejar();
            }

            Pareja = persona;
            persona.Pareja = this;
        }

        public void Desemparejar()
        {
            if (Pareja != null)
            {
                Pareja.Pareja = null;
                Pareja = null;
            }
        }

        [ContractInvariantMethod]
        private void InvarianteMonogamia()
        {
            Contract.Invariant(this.Pareja == null || this.Pareja.Pareja == this, "No se cumple la monogamia");
        }

        public override string ToString()
        {
            if (Pareja != null)
            {
                return $"{Nombre} -> {Pareja.Nombre}";
            }
            return Nombre;
        }
    }
}
