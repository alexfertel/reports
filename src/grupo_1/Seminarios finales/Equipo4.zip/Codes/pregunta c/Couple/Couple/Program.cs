﻿using System;

namespace Couple
{
    class Program
    {
        public static void print(Persona[] personas)
        {
            foreach(var i in personas)
            {
                Console.WriteLine(i);
            }
        }
        static void Main(string[] args)
        {
            Persona[] personas =
            {
                new Persona("Alberto"),
                new Persona("Gerbacio"),
                new Persona("Petunia"),
                new Persona("Ursula")
            };

            Console.WriteLine("Emparejando Alberto con Petunia");
            personas[0].Emparejar(personas[2]);
            print(personas);
            Console.WriteLine("Emparejando Gerbacio con Ursula");
            personas[1].Emparejar(personas[3]);
            print(personas);
            Console.WriteLine("Emparejando Alberto con Ursula");
            personas[0].Emparejar(personas[3]);
            print(personas);
            Console.WriteLine("Emparejando Gerbacio con Petunia");
            personas[1].Emparejar(personas[2]);
            print(personas);
        }
    }
}
