﻿#define CONTRACTS_FULL

using System;
using System.Diagnostics.Contracts;
using System.Collections.Generic;

namespace lp_example
{
    [ContractClass(typeof(ContractPriorityQueue<>))]
    public interface IQueue<T> where T: IComparable<T>
    {
        void Push(T o);
        T Pop();
        T Peek();
        int Count { get; }
    }

    [ContractClassFor(typeof(IQueue<>))]
    abstract class ContractPriorityQueue<T>: IQueue<T> where T: IComparable<T>
    {
        Dictionary<T, int> d;
        public void Push(T element)
        {
            Contract.Requires(element != null, "Cannot push a null element.");
            Contract.Ensures(Count == Contract.OldValue(Count) + 1, "After pushed an element queue's length should increase by 1.");
            Contract.Ensures(d.ContainsKey(element), "Queue must contains the pushed element.");
            throw new NotImplementedException();
        }
        public T Pop()
        {
            Contract.Requires(Count > 0, "Queue cannnot be empty when poping an element");
            Contract.Ensures(Count == Contract.OldValue(Count) - 1, "When poped an element queue's length should decrease by 1.");
            Contract.Ensures(Contract.ForAll(d, e => e.Key.CompareTo(Contract.Result<T>()) <= 0), "The element with the highest priority must be extracted.");
            throw new NotImplementedException();
        }
        public T Peek()
        {
            Contract.Requires(Count > 0, "Queue cannot be empty.");
            Contract.Ensures(Contract.ForAll(d, x => x.Key.CompareTo(Contract.Result<T>()) <= 0), "The element with the highest priority must be returned.");
            throw new NotImplementedException();
        }
        public int Count
        {
            get
            {
                Contract.Requires(Count >= 0);
                throw new NotImplementedException();
            }
        }
        [ContractInvariantMethod]
        void PriorityQueueInvariant()
        {
            Contract.Invariant(Count >= 0, "Cuantity of elements cannot be negative");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
