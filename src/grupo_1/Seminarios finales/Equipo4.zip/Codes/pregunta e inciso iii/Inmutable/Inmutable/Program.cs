﻿using System;
using System.Diagnostics.Contracts;

namespace Inmutable
{
    class Program
    {
        public interface IInmutable<T> : ICloneable, IComparable<T>
        {
        }

        class Deposito : IInmutable<Deposito>
        {
            public double cantidad { get; set; }
            public Deposito(double cantidadInicial = 0)
            {
                cantidad = cantidadInicial;
            }

            public object Clone()
            {
                return new Deposito(cantidad);
            }

            public int CompareTo(Deposito other)
            {
                if (cantidad == other.cantidad) return 0;
                if (cantidad < other.cantidad) return -1;
                return 1;
            }
        }

        class Usuario
        {
            public string Nombre { get; private set; }
            public Deposito Cuenta { get; private set; }
            public Usuario(string nombre, int cantidadInicial = 0)
            {
                Contract.Requires(!string.IsNullOrEmpty(nombre), "El nombre no debe estar vacío ni ser null");
                Contract.Requires(Cuenta.cantidad >= 0, "La cantidad debe ser positiva");

                Cuenta = new Deposito(cantidadInicial);
            }

            public void AgregarSaldo(double transferencia)
            {
                Contract.Requires(transferencia > 0, "La cantidad debe ser positiva");
                Contract.Ensures(Cuenta.CompareTo(Contract.OldValue((Deposito)Cuenta.Clone())) < 0);

                Cuenta.cantidad += transferencia;
            }
        }

        static void Main(string[] args)
        {
            Usuario a = new Usuario("Pepe", 0);

            a.AgregarSaldo(2);
        }
    }
}
