﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ProyectoLPCSharp
{

    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 1 && uint.TryParse(args[0], out uint n))
            {
                var timer = new Stopwatch();
                timer.Start();
                Console.WriteLine(QueenSolver.SolveNQueen(n));
                timer.Stop();
                Console.WriteLine($"Milisegundos: {timer.ElapsedMilliseconds}");
            }
            else
                Console.WriteLine("Escriba un entero para resolver el problema de las reinas.");
        }
    }
}
