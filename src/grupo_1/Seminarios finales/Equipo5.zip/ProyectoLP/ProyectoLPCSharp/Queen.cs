﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProyectoLPCSharp
{

    class QueenChessboard
    {
        private bool[] _horizontalTaken;

        private bool[] _verticalTaken;

        private Stack<(int, int)> _queens;

        public int Length => _horizontalTaken.Length;

        public QueenChessboard(uint n)
        {
            _horizontalTaken = new bool[n];
            _verticalTaken = new bool[n];
            _queens = new Stack<(int, int)>();
        }

        public bool IsSafe(int row, int col)
        {
            if (_horizontalTaken[row] || _verticalTaken[col])
                return false;

            foreach (var (row0, col0) in _queens)
            {
                // y = mx + n
                // m = 1 or -1    diagonal slope
                // y - y0 = m(x - x0)   where y0 and x0 are the position of the queen
                if (row - row0 == col - col0 || row - row0 == -col + col0)
                    return false;
            }

            return true;
        }

        public bool PushQueen(int row, int col)
        {
            if (IsSafe(row, col))
            {
                _queens.Push((row, col));
                _horizontalTaken[row] = true;
                _verticalTaken[col] = true;
                return true;
            }
            return false;
        }

        public void PopQueen()
        {
            (var row, var col) = _queens.Pop();
            _horizontalTaken[row] = false;
            _verticalTaken[col] = false;
        }

        public bool ValidRow(int row) => !_horizontalTaken[row];

        public bool ValidCol(int col) => !_verticalTaken[col];

        public override string ToString()
        {
            var repr = "  ";
            for (int i = 0; i < Length; i++)
            {
                repr += i.ToString() + " ";
            }
            repr += "\n";
            for (int i = 0; i < Length; i++)
            {
                repr += i.ToString() + " ";
                for (int j = 0; j < Length; j++)
                {
                    if (_queens.Any(x => x.Item1 == i && x.Item2 == j))
                        repr += "Q" + " ";
                    else
                        repr += "X" + " ";
                }
                repr += "\n";
            }
            return repr;
        }
    }
    
    class QueenSolver
    {

        static QueenChessboard chessboard { get; set; }

        public static uint SolveNQueen(uint n)
        {
            chessboard = new QueenChessboard(n);
            return _solveNQueen(n, 0);
        }

        static uint _solveNQueen(uint n, int row)
        {
            if (n == 0)
            {
                //Console.WriteLine(chessboard); // Uncomment to print valid positions
                return 1;
            }

            uint current_solutions = 0;
            for (int j = 0; j < chessboard.Length; j++)
            {
                if (chessboard.PushQueen(row, j))
                {
                    uint solutions = _solveNQueen(n - 1, row + 1);
                    current_solutions += solutions;
                    chessboard.PopQueen();
                }
            }
            return current_solutions;
        }

    }

}
