﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoLPCSharp
{
    class QuickSort
    {
        public static void Quicksort(int[] a, int init, int end)
        {
            if (init < end)
            {
                int q = Partition(a, init, end);
                Quicksort(a, init, q);
                Quicksort(a, q + 1, end);
            }
        }

        static int Partition(int[] a, int init, int end)
        {
            int pivot = a[init];
            int i = init - 1;
            int e = end + 1;

            while (true)
            {
                do e--; while (pivot < a[e]);
                do i++; while (pivot > a[i]);
                if (i < e)
                {
                    int temp = a[i];
                    a[i] = a[e];
                    a[e] = temp;
                }
                else return e;

            }
        }
    }
}
