﻿module NQueens
let printBoard size queens = 
    printfn "%s" ("  " + (List.reduce (+) (List.map (fun x -> x.ToString() + " ") [0 .. size - 1])))
    for i in 0 .. size - 1 do
        printfn "%d %s" i (List.reduce (+) [
            for j in 0 .. size - 1 do 
                if List.exists (fun x -> fst x = i && snd x = j) queens then 
                    yield "Q "  
                else 
                    yield "X "])
    printf "\n"

let invalid x0 y0 cell =
    match cell with
    | (x1, y1) -> y0 - y1 = x0 - x1 || y0 - y1 = x1 - x0 || x1 = x0 || y1 = y0

let posValid x y queens = not <| List.exists (invalid x y) queens

let rec queenRec size queenLeft currentRow queens =
    if queenLeft = 0 then
        //printBoard size queens // Uncomment to print valid positions
        1
    else
        List.fold (+) 0 [ 
            for i in 0 .. size - 1 do 
                if posValid currentRow i queens then 
                    yield queenRec size (queenLeft - 1) (currentRow + 1) ((currentRow, i)::queens) ]
        
let queen n = queenRec n n 0 []
