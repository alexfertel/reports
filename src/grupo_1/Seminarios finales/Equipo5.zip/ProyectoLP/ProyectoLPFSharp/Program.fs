﻿// Learn more about F# at http://fsharp.org

open System
open QuickSort
open NQueens


[<EntryPoint>]
let main argv =
    let timer = System.Diagnostics.Stopwatch.StartNew()
    match argv with
    | [| queenNumber |] -> int32 queenNumber |> queen |> printfn "%d"
    | _ -> printfn "Escriba un entero para resolver el problema de las reinas"
    timer.Stop()
    printfn "Milisegundos: %f" timer.Elapsed.TotalMilliseconds
    0 // return an integer exit code
