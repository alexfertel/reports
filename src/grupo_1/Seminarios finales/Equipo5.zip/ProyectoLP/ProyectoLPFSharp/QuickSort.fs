﻿module QuickSort

let rec quicksort objects = 
    match objects with
    | [] -> []
    | first :: rest -> quicksort (List.filter ((<=) first) rest)
                     @ [first] 
                     @ quicksort (List.filter ((>) first) rest)

