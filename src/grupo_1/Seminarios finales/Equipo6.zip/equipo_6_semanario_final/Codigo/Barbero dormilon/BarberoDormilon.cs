﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Barbero_durmiente
{
    class BarberoDurmiente
    {
        private Semaphore mutex { get; set; }
        private Semaphore blockColors { get; set; }
        private Queue<int> clientes { get; set; }
        private int id { get; set; }

        public int CantidadSillas { get; private set; }

        public BarberoDurmiente(int cantidadSillas)
        {
            if (cantidadSillas < 0)
                throw new Exception("LA CANTIDAD DE SILLAS NO PUEDE SER NEGATIVA");

            id = 1;
            mutex = new Semaphore(1, 1);
            blockColors = new Semaphore(1, 1);
            clientes = new Queue<int>();
            CantidadSillas = cantidadSillas;
        }

        public void Simular()
        {
            Thread generarClientes = new Thread(() => GenerarClientes());
            Thread barbero = new Thread(() => Barbero());

            generarClientes.Start();
            barbero.Start();
            generarClientes.Join();
            barbero.Join();
        }

        private void GenerarClientes()
        {
            Random random = new Random();

            while (true)
            {
                mutex.WaitOne();

                if (clientes.Count > CantidadSillas)
                    Imprimir("La barberia esta llena", ConsoleColor.Red);
                else
                {
                    clientes.Enqueue(id);
                    Imprimir("El cliente " + id.ToString() + " llega a la barberia",
                        ConsoleColor.Yellow);
                    id++;
                }

                mutex.Release();
                int tiempoLlegadaClientes = random.Next(1, 3);
                Thread.Sleep(TimeSpan.FromSeconds(tiempoLlegadaClientes));
            }
        }

        private void Barbero()
        {
            while (true)
            {
                mutex.WaitOne();

                if (clientes.Count > 0)
                {
                    int cliente = clientes.Dequeue();
                    mutex.Release();
                    Imprimir("El barbero empezo a cortarle el cabello al cliente " +
                        cliente.ToString(), ConsoleColor.Green);
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                    Imprimir("El barbero termino de cortarle el cabello al cliente " +
                        cliente.ToString(), ConsoleColor.Green);

                    if (clientes.Count == 0)
                        Imprimir("El barbero esta durmiendo", ConsoleColor.Blue);
                }
                else
                {
                    Imprimir("El barbero esta durmiendo", ConsoleColor.Blue);
                    mutex.Release();
                }

                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        private void Imprimir(string texto, ConsoleColor color)
        {
            blockColors.WaitOne();

            Console.ForegroundColor = color;
            Console.WriteLine(texto);
            Console.ResetColor();

            blockColors.Release();
        }
    }

    class Program
    {
        public static void Main(string[] args)
        {
            BarberoDurmiente barbero = new BarberoDurmiente(5);
            barbero.Simular();
        }
    }
}
