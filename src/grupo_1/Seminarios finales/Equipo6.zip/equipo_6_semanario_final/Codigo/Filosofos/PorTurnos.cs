﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SolucionPorTurnos
{
    public class PorTurnos
    {
        private string[] names = { "Tales", "Anaximandro", "Pitagoras",
            "Heraclito", "Socrates" };
        private Semaphore mutex;
        private Semaphore blockColor;
        private Thread[] philosopherThread;

        public PorTurnos()
        {
            mutex = new Semaphore(1, 1);
            blockColor = new Semaphore(1, 1);
            philosopherThread = new Thread[names.Length];
        }

        private void Print(string text, string philosopher)
        {
            blockColor.WaitOne();

            if (philosopher == "Tales")
                Console.ForegroundColor = ConsoleColor.Blue;
            else if (philosopher == "Anaximandro")
                Console.ForegroundColor = ConsoleColor.Green;
            else if (philosopher == "Pitagoras")
                Console.ForegroundColor = ConsoleColor.Red;
            else if (philosopher == "Heraclito")
                Console.ForegroundColor = ConsoleColor.Yellow;
            else
                Console.ForegroundColor = ConsoleColor.Gray;

            Console.WriteLine(text);
            Console.ResetColor();
            blockColor.Release();
        }

        public void Simular()
        {
            for (int i = 0; i < philosopherThread.Length; i++)
            {
                int index = i;
                philosopherThread[index] = new Thread(() => Turno(names[index]));
                philosopherThread[index].Start();
            }

            for (int i = 0; i < philosopherThread.Length; i++)
            {
                philosopherThread[i].Join();
            }
        }

        private void Turno(string philosopher)
        {
            Random random = new Random();

            while (true)
            {
                if (random.Next(0, 2) == 0)
                {
                    Print("[" + philosopher + "]: Tengo hambre", philosopher);
                    mutex.WaitOne();
                    Print("[" + philosopher + "]: Estoy comiendo", philosopher);
                    Thread.Sleep(TimeSpan.FromSeconds(random.Next(1, 3)));
                    Print("[" + philosopher + "]: Ya comi", philosopher);
                    mutex.Release();
                }
                else
                    Print("[" + philosopher + "]: Estoy pensando", philosopher);

                Thread.Sleep(TimeSpan.FromSeconds(random.Next(1, 5)));
            }
        }
    }
}
