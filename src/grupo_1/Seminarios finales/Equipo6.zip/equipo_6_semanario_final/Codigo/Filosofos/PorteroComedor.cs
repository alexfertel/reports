﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SolucionPorteroComedor
{
    public class PorteroComedor
    {
        private string[] names = { "Tales", "Anaximandro", "Pitagoras", "Heraclito",
            "Socrates" };
        private Semaphore blockColor;
        private Semaphore mutex;
        private int[] countForks;
        private Semaphore[] forks;
        private Thread[] philosopherThread;

        public PorteroComedor()
        {
            blockColor = new Semaphore(1, 1);
            mutex = new Semaphore(1, 1);
            countForks = new int[names.Length];
            forks = new Semaphore[names.Length];
            philosopherThread = new Thread[names.Length];

            for (int i = 0; i < names.Length; i++)
            {
                countForks[i] = 0;
                forks[i] = new Semaphore(1, 1);
            }
        }

        private void Print(string text, string philosopher)
        {
            blockColor.WaitOne();

            if (philosopher == "Tales")
                Console.ForegroundColor = ConsoleColor.Blue;
            else if (philosopher == "Anaximandro")
                Console.ForegroundColor = ConsoleColor.Green;
            else if (philosopher == "Pitagoras")
                Console.ForegroundColor = ConsoleColor.Red;
            else if (philosopher == "Heraclito")
                Console.ForegroundColor = ConsoleColor.Yellow;
            else
                Console.ForegroundColor = ConsoleColor.Gray;

            Console.WriteLine(text);
            Console.ResetColor();
            blockColor.Release();
        }

        public void Simular()
        {
            for (int i = 0; i < philosopherThread.Length; i++)
            {
                int index = i;
                philosopherThread[index] = new Thread(() => Portero(index, names[index]));
                philosopherThread[index].Start();
            }

            for (int i = 0; i < philosopherThread.Length; i++)
            {
                philosopherThread[i].Join();
            }
        }

        private void Portero(int id, string philosopher)
        {
            for (int k = 0; k < names.Length; k++)
            {
                mutex.WaitOne();
                int rightFork = id % names.Length;
                int leftFork = (id + 1) % names.Length;

                if (countForks[rightFork] == 0 && countForks[leftFork] == 0)
                {
                    Print("[" + philosopher + "]: Tengo hambre", philosopher);
                    Print("[" + philosopher + "]: Tengo los tenedores " +
                        rightFork.ToString() + " y " + leftFork.ToString(), philosopher);

                    forks[rightFork].WaitOne();
                    countForks[rightFork] = 1;
                    forks[leftFork].WaitOne();
                    countForks[leftFork] = 1;
                }
                else
                {
                    k -= 1;
                    mutex.Release();
                    continue;
                }
                mutex.Release();

                Print("[" + philosopher + "]: Estoy comiendo", philosopher);
                Thread.Sleep(5000);
                Print("[" + philosopher + "]: Ya comi", philosopher);

                forks[rightFork].Release();
                forks[leftFork].Release();
                countForks[rightFork] = 0;
                countForks[leftFork] = 0;
                Print("[" + philosopher + "]: Suelto los tenedores " +
                    rightFork.ToString() + " y " + leftFork.ToString(), philosopher);
            }
        }
    }
}
