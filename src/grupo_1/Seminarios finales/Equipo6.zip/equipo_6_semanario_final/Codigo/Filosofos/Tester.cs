﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SolucionPorTurnos;
using SolucionVariosTurnos;
using SolucionPorteroComedor;

namespace Filosofos
{
    class Tester
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ESCRIBA UN NUMERO, INDICANDO EL NUMERO DE SOLUCION POR EL ");
            Console.WriteLine("QUE DESEA SIMULAR EL PROBLEMA DE LOS FILOSOFOS CENANDO:");
            Console.WriteLine("1. SOLUCION POR TURNOS");
            Console.WriteLine("2. SOLUCION POR VARIOS TURNOS");
            Console.WriteLine("3. SOLUCION DEL PORTERO DEL COMEDOR");
            int solution = int.Parse(Console.ReadLine());
            Console.WriteLine();

            if (solution == 1)
            {
                PorTurnos turnos = new PorTurnos();
                turnos.Simular();
            }
            else if (solution == 2)
            {
                VariosTurnos variosTurnos = new VariosTurnos();
                variosTurnos.Simular();
            }
            else
            {
                PorteroComedor portero = new PorteroComedor();
                portero.Simular();
            }
        }
    }
}
