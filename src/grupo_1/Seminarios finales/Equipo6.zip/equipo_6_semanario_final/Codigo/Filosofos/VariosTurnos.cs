﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SolucionVariosTurnos
{
    public class VariosTurnos
    {
        private Semaphore blockColor;
        private Semaphore[] forks;
        private Thread[] philosopherThread;
        private string[] names = { "Tales", "Anaximandro", "Pitagoras", "Heraclito",
            "Socrates" };

        public VariosTurnos()
        {
            blockColor = new Semaphore(1, 1);
            forks = new Semaphore[names.Length];
            philosopherThread = new Thread[names.Length];

            for (int i = 0; i < forks.Length; i++)
            {
                forks[i] = new Semaphore(1, 1);
            }
        }

        private void Print(string text, string philosopher)
        {
            blockColor.WaitOne();

            if (philosopher == "Tales")
                Console.ForegroundColor = ConsoleColor.Blue;
            else if (philosopher == "Anaximandro")
                Console.ForegroundColor = ConsoleColor.Green;
            else if (philosopher == "Pitagoras")
                Console.ForegroundColor = ConsoleColor.Red;
            else if (philosopher == "Heraclito")
                Console.ForegroundColor = ConsoleColor.Yellow;
            else
                Console.ForegroundColor = ConsoleColor.Gray;

            Console.WriteLine(text);
            Console.ResetColor();
            blockColor.Release();
        }

        public void Simular()
        {
            for (int i = 0; i < philosopherThread.Length; i++)
            {
                int index = i;
                philosopherThread[index] = new Thread(() => PorVariosTurnos(index));
                philosopherThread[index].Start();
            }

            for (int i = 0; i < philosopherThread.Length; i++)
            {
                philosopherThread[i].Join();
            }
        }

        private void PorVariosTurnos(int id)
        {
            Random random = new Random();

            while (true)
            {
                if (random.Next(2) == 0)
                    Print("[" + names[id] + "]: Estoy pensando", names[id]);
                else
                {
                    Print("[" + names[id] + "]: Tengo hambre", names[id]);
                    forks[id % forks.Length].WaitOne();
                    forks[(id + 1) % forks.Length].WaitOne();
                    Print("[" + names[id] + "]: Estoy comiendo", names[id]);
                    Thread.Sleep(TimeSpan.FromSeconds(4));
                    Print("[" + names[id] + "]: Ya comi", names[id]);
                    forks[id % forks.Length].Release();
                    forks[(id + 1) % forks.Length].Release();
                }
                Thread.Sleep(TimeSpan.FromSeconds(random.Next(1, 5)));
            }
        }
    }
}
