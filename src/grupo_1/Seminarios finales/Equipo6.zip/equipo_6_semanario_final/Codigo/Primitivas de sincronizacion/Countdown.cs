﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Primitivas_de_sincronizacion
{
    public class MyCountdown
    {
        private Semaphore block;
        private Semaphore countdown;
        private int waitingThreads;

        /// <summary>
        /// Obtiene el número de señales restantes necesario para establecer el evento.
        /// </summary>
        /// <returns>
        /// Devuelve el número de señales restantes necesario para establecer el evento.
        /// </returns>
        public int CurrentCount { get; private set; }

        /// <summary>
        /// Obtiene los números de señales que se necesitan inicialmente para establecer 
        /// el evento.
        /// </summary>
        /// <returns>
        /// Devuelve el número de señales que se necesitan inicialmente para establecer 
        /// el evento.
        /// </returns>
        public int InitialCount { get; private set; }

        /// <summary>
        /// Inicializa una nueva instancia de la clase MyCountdown con el recuento 
        /// especificado.
        /// </summary>
        /// <param name="initialCount">
        /// Número de señales necesarias inicialmente para establecer MyCountdown.
        /// </param>
        public MyCountdown(int initialCount)
        {
            if (initialCount < 0)
                throw new ArgumentOutOfRangeException();

            InitialCount = initialCount;
            CurrentCount = initialCount;
            waitingThreads = 0;
            block = new Semaphore(1, 1);
            countdown = new Semaphore(0, int.MaxValue);
        }

        /// <summary>
        /// Incrementa en uno el recuento actual de MyCountdown.
        /// </summary>
        public void AddCount()
        {
            block.WaitOne();
            CurrentCount++;
            block.Release();
        }

        /// <summary>
        /// Restablece el valor de CurrentCount en el valor de InitialCount.
        /// </summary>
        public void Reset()
        {
            block.WaitOne();
            CurrentCount = InitialCount;
            block.Release();
        }

        /// <summary>
        /// Registra una señal y disminuye el valor de CurrentCount.
        /// </summary>
        /// <returns>
        /// Devuelve true si la señal hizo que el recuento alcanzara el valor cero de lo 
        /// contrario devuelve falso.
        /// </returns>
        public bool Signal()
        {
            block.WaitOne();
            if (CurrentCount > 1)
            {
                CurrentCount--;
                block.Release();
                return false;
            }
            else
            {
                countdown.Release(waitingThreads);
                waitingThreads = 0;
                block.Release();
                return true;
            }
        }

        /// <summary>
        /// Bloquea el subproceso actual hasta que se establezca el objeto MyCountdown.
        /// </summary>
        public void Wait()
        {
            block.WaitOne();
            if (CurrentCount > 0)
            {
                waitingThreads++;
                block.Release();
                countdown.WaitOne();
            }
            else
                block.Release();
        }
    }
}
