﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Primitivas_de_sincronizacion
{
    class Tester
    {
        #region TESTING SEMAPHORE

        public static Random rand;
        public static Semaphore semaphore;

        public static void TestingSemaphore()
        {
            rand = new Random();
            semaphore = new Semaphore(3, 3);

            for (int i = 1; i <= 10; i++)
            {
                Thread thread = new Thread(() => WatchingMovies());
                thread.Name = i.ToString();
                thread.Start();
            }
        }

        public static void WatchingMovies()
        {
            semaphore.WaitOne();
            Console.WriteLine("Cliente {0} entra al teatro.", Thread.CurrentThread.Name);
            Thread.Sleep(TimeSpan.FromSeconds(rand.Next(1, 5)));
            Console.WriteLine("Cliente {0} sale del teatro.", Thread.CurrentThread.Name);
            semaphore.Release();
        }

        #endregion

        #region TESTING BARRIER

        public static Barrier my_barrier;

        public static void Play(string name, string message, int time)
        {
            for (int i = 1; i <= 3; i++)
            {
                Thread.Sleep(TimeSpan.FromSeconds(time));
                Console.WriteLine("{0} empieza a {1}", name, message);

                Thread.Sleep(TimeSpan.FromSeconds(time));
                Console.WriteLine("{0} finaliza de {1}", name, message);

                my_barrier.SignalAndWait();
                Console.WriteLine();
            }
        }

        public static void TestingMyBarrier()
        {
            my_barrier = new Barrier(3);

            Thread thread1 = new Thread(() => Play("El guitarrista", 
                "tocar su guitarra.", 2));
            Thread thread2 = new Thread(() => Play("El vocalista", 
                "cantar su canción.", 3));
            Thread thread3 = new Thread(() => Play("El pianista", 
                "tocar el piano.", 4));

            thread1.Start();
            thread2.Start();
            thread3.Start();

            thread1.Join();
            thread2.Join();
            thread3.Join();
        }

        #endregion

        #region TESTING COUNTDOWN

        public static string[] students = { "Yenli", "Jotica", "Yunior", "Carlos", "Ariel" };
        public static Random random;
        public static MyCountdown my_countdown;

        public static void Arrive(int student)
        {
            Thread.Sleep(TimeSpan.FromSeconds(random.Next(1, 5)));
            Console.WriteLine("El alumno {0} llega al aula.", students[student]);
            my_countdown.Signal();
        }

        public static void ArrivePeople()
        {
            for (int i = 0; i < students.Length; i++)
            {
                new Thread(() => Arrive(i)).Start();
                Thread.Sleep(TimeSpan.FromSeconds(random.Next(1, 5)));
            }
        }

        public static void TestingMyCoutdown()
        {
            random = new Random();
            my_countdown = new MyCountdown(5);
            Console.WriteLine("Son las 7:55 am. Va a empezar la clase de LP.");
            Console.WriteLine();

            new Thread(() => ArrivePeople()).Start();
            my_countdown.Wait();

            Console.WriteLine();
            Console.WriteLine("8:00 am!!! Empieza la clase.");
        }

        #endregion

        #region TESTING MONITOR

        public static int x;
        public static object obj;

        public static void FunctionSum()
        {
            for (int i = 0; i < 100000; i++)
            {
                MyMonitor.Enter(obj);
                x += 1;
                MyMonitor.Exit(obj);
            }
        }

        public static void FunctionRest()
        {
            for (int i = 0; i < 100000; i++)
            {
                MyMonitor.Enter(obj);
                x -= 1;
                MyMonitor.Exit(obj);
            }
        }

        public static void TestingMyMonitor()
        {
            x = 0;
            obj = new object();

            Thread thread1 = new Thread(() => FunctionSum());
            Thread thread2 = new Thread(() => FunctionRest());

            thread1.Start();
            thread2.Start();
            thread1.Join();
            thread2.Join();

            Console.WriteLine("El valor de la variable estatica es {0}.", x);
        }

        #endregion

        static void Main(string[] args)
        {
            //TestingSemaphore();

            //TestingMyMonitor();

            //TestingMyBarrier();

            //TestingMyCoutdown();
        }
    }
}
