using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Barriers
{
    class Program
    {
        private static void CreatePlanets(int participantNum)
        {
            Console.WriteLine("Creating Planets. Participant # {0}",participantNum);
        }
        private static void CreateStars(int participantNum)
        {
            Console.WriteLine("Creating Stars. Participant # {0}",participantNum);
        }
        private static void CheckCollisionsBetweenPlanets(int participantNum)
        {
            Console.WriteLine("Checking collisions between planets. Participant # {0}",participantNum);
        }
        private static void CheckCollisionsBetweenStars(int participantNum)
        {
            Console.WriteLine("Checking collisions between stars. Participant # {0}", participantNum);
        }
        private static void RenderCollisions(int participantNum)
        {
            Console.WriteLine("Rendering collisions. Participant # {0}", participantNum);
        }
        private static int _participants = Environment.ProcessorCount;
        private static Task[] _tasks;
        private static Barrier _barriers;
        static void Main(string[] args)
        {
            _tasks = new Task[_participants];
            _barriers = new Barrier(_participants, (barrier) =>
            {
                Console.WriteLine("Current phase: {0}",barrier.CurrentPhaseNumber);
            });
            for (int i = 0; i < _participants; i++)
            {
                _tasks[i] = Task.Factory.StartNew( (num) =>
                {
                    var participantNumber = (int)num;
                    for (int j = 0; j < 1; j++)
                    {
                        CreatePlanets(participantNumber);
                        _barriers.SignalAndWait();
                        CreateStars(participantNumber);
                        _barriers.SignalAndWait();
                        CheckCollisionsBetweenPlanets(participantNumber);
                        _barriers.SignalAndWait();
                        CheckCollisionsBetweenStars(participantNumber);
                        _barriers.SignalAndWait();
                        RenderCollisions(participantNumber);
                        _barriers.SignalAndWait();
                    }
                },i);
            }
            var finalTask = Task.Factory.ContinueWhenAll(_tasks, (tasks) =>
            {
                Task.WaitAll(_tasks);
                Console.WriteLine("All the phases where executed.");
                _barriers.Dispose();
            });
            finalTask.Wait();
            Console.ReadLine();
        }
    }
}
