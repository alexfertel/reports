using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace Countdown
{
    class Program
    {
        private static CountdownEvent _countdown;
        private static int MIN_PATHS = Environment.ProcessorCount;
        private static int MAX_PATHS = Environment.ProcessorCount*3;

        private static void SimulatePaths(int pathCount)
        {
            for(int i = 0;i < pathCount; i++)
            {
                Task.Factory.StartNew((num) =>
               {
                   try
                   {
                       var pathNumber = (int)num;
                       //var sw = Stopwatch.StartNew();
                       var rnd = new Random();
                       Thread.Sleep(rnd.Next(2000, 5000));
                       Console.WriteLine("Path {0} simulated.",pathNumber);
                   }
                   finally
                   {
                       _countdown.Signal();
                   }
               },i);
            }
        }

        static void Main(string[] args)
        {
            _countdown = new CountdownEvent(MIN_PATHS);
            var t1 = Task.Factory.StartNew(() =>
           {
               for (int i = MIN_PATHS; i <= MAX_PATHS; i++)
               {
                   Console.WriteLine(">>>> {0} Concurrent path start", i);
                   _countdown.Reset(i);
                   SimulatePaths(i);
                   _countdown.Wait();
                   Console.WriteLine("<<<< {0} Concurrent path end", i);
               }
           });
            try
            {
                t1.Wait();
                Console.WriteLine("The simulation was executed.");
            }
            finally
            {
                _countdown.Dispose();
            }
            Console.ReadLine();
        }
    }
}
