using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Barriers_with_semaphore
{
    class My_Barrier
    {
        Semaphore temp;
        Semaphore s;
        public int ParticipantCount;
        public long CurrentPhaseNumber;
        public int RemainingParticipamts;
       
        public My_Barrier(int participantCount)
        {
            this.ParticipantCount = participantCount;
            this.RemainingParticipamts = participantCount;
            this.CurrentPhaseNumber = 0;
            this.temp = new Semaphore(1, 1);
            this.s = new Semaphore(0, participantCount - 1);
        }
        
        public void SignalAndWait()
        {
            temp.WaitOne();
            if (this.RemainingParticipamts > 1)
            {

                this.RemainingParticipamts--;
                temp.Release();
                s.WaitOne();
            }
            else
            {
                s.Release(this.ParticipantCount - 1);
                Console.WriteLine("Current phase: {0}", this.CurrentPhaseNumber);
                this.CurrentPhaseNumber++;
                this.RemainingParticipamts = this.ParticipantCount;
                temp.Release();
            }
        }
    }
    class Program
    {
        private static void CreatePlanets(int participantNum)
        {
            Console.WriteLine("Creating Planets. Participant # {0}", participantNum);
        }
        private static void CreateStars(int participantNum)
        {
            Console.WriteLine("Creating Stars. Participant # {0}", participantNum);
        }
        private static int _participants = Environment.ProcessorCount;
        private static Task[] _tasks;
        private static My_Barrier _barriers;
        static void Main(string[] args)
        {
            _tasks = new Task[_participants];
            _barriers = new My_Barrier(_participants);
            for (int i = 0; i < _participants; i++)
            {
                _tasks[i] = Task.Factory.StartNew((num) =>
                {
                    var participantNumber = (int)num;
                    for (int j = 0; j < 1; j++)
                    {
                        CreatePlanets(participantNumber);
                        _barriers.SignalAndWait();
                        CreateStars(participantNumber);
                        _barriers.SignalAndWait();
                    }
                }, i);
            }
            var finalTask = Task.Factory.ContinueWhenAll(_tasks, (tasks) =>
            {
                Task.WaitAll(_tasks);
                Console.WriteLine("All the phases where executed.");
            });
            finalTask.Wait();
            Console.ReadLine();
        }
    }
}
