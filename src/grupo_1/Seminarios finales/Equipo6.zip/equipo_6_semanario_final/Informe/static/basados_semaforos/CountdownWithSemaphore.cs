using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace Countdown
{
    class My_Countdown
    {
        Semaphore s;
        Semaphore temp;
        public int InitialCount;
        public int CurrentCount;
        public My_Countdown(int initialCountdown)
        {
            if (initialCountdown < 0)
                throw new ArgumentOutOfRangeException();
            this.InitialCount = initialCountdown;
            this.CurrentCount = this.InitialCount;
            temp = new Semaphore(1, 1);
            s = new Semaphore(0, 1);
        }
        public void Reset()
        {
            this.CurrentCount = this.InitialCount;
            temp = new Semaphore(1, 1);
            s = new Semaphore(0, 1);
            temp.Release();
        }
        public void Reset(int i)
        {
            this.CurrentCount = i;
            temp = new Semaphore(1, 1);
            s = new Semaphore(0, 1);
        }
        public void Wait()
        {
            s.WaitOne();
        }
        public bool Signal()
        {
            temp.WaitOne();
            if(this.CurrentCount > 1)
            {
                this.CurrentCount--;
                temp.Release();
                return false;
            }
            else
            {
                temp.Release();
                s.Release();
                return true;
            }
        }
    }
    class Program
    {
        private static My_Countdown _countdown;
        private static int MIN_PATHS = Environment.ProcessorCount;
        private static int MAX_PATHS = Environment.ProcessorCount * 3;

        private static void SimulatePaths(int pathCount)
        {
            for (int i = 0; i < pathCount; i++)
            {
                Task.Factory.StartNew((num) =>
                {
                    try
                    {
                        var pathNumber = (int)num;
                        var sw = Stopwatch.StartNew();
                        var rnd = new Random();
                        Thread.Sleep(rnd.Next(2000, 5000));
                        Console.WriteLine("Path {0} simulated.", pathNumber);
                    }
                    finally
                    {
                        _countdown.Signal();
                    }
                }, i);
            }
        }

        static void Main(string[] args)
        {
            _countdown = new My_Countdown(MIN_PATHS);
            var t1 = Task.Factory.StartNew(() =>
            {
                for (int i = MIN_PATHS; i <= MAX_PATHS; i++)
                {
                    Console.WriteLine(">>>> {0} Concurrent path start", i);
                    _countdown.Reset(i);
                    SimulatePaths(i);
                    _countdown.Wait();
                    Console.WriteLine("<<<< {0} Concurrent path end", i);
                }
            });
            try
            {
                t1.Wait();
                Console.WriteLine("The simulation was executed.");
            }
            finally
            {
                
            }
            Console.ReadLine();
        }
    }
}
