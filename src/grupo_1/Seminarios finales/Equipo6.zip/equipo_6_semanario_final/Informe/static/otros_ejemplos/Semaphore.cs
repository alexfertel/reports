using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;


namespace semaphore
{
    class Program
    {
        private static Task[] _tasks;
        private static Semaphore _semaphore;
        private const int Max_Machines = 3;
        private static int _attackers = Environment.ProcessorCount;

        private static void SimulateAttacks(int attackerNumber)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Random rnd = new Random();
            Thread.Sleep(rnd.Next(2000, 5000));
            Console.WriteLine("WAIT ## Attacker {0} requested to enter the semaphore.", attackerNumber);
            _semaphore.WaitOne();
            try
            {
                Console.WriteLine("ENTER ---> Attacker {0} entered the semaphore.", attackerNumber);
                sw.Restart();
                Thread.Sleep(rnd.Next(2000, 5000));
                _semaphore.Release();
                Console.WriteLine("RELEASE <--- Attacker {0} released the semaphore.", attackerNumber);
            }
            catch
            { }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("There are {0} attackers.",_attackers);
            _tasks = new Task[_attackers];
            _semaphore = new Semaphore(Max_Machines, Max_Machines);
            Console.WriteLine("{0} attackers are going to be able to enter the semaphore.", Max_Machines);
            for(int i = 0;i < _attackers;i++)
            {
                _tasks[i] = Task.Factory.StartNew((num) =>
                {
                    var attackerNumber = (int)num;
                    for (int j = 0; j < 1; j++)
                    {
                        SimulateAttacks(attackerNumber);
                    }
                }, i);
            }
            var finalTask =
                Task.Factory.ContinueWhenAll(_tasks, (tasks) =>
                 {
                     Task.WaitAll();
                     Console.WriteLine("The simulation was executed.");
                     _semaphore.Dispose();
                 });
            finalTask.Wait();
            Console.ReadLine();
        }
    }
}
