import { IEnumerator } from "./interfaces/IEnumerator";

export class Enumerator<T> implements IEnumerator<T> {
    
    items: T[];
    indx: number;
    defautlInd: number;
    step: number;
    
    /**
     * 
     * @param elems Lista de elementos
     * @param startIndex Índice desde donde se empieza a recorrer
     * @param step Cantidad y dirección de los pasos durante el recorrido
     */
    constructor(elems: T[], startIndex: number = -1, step: number = 1) {
        this.items = elems;
        this.indx = startIndex;
        this.defautlInd = startIndex;
        this.step = step;
    }
    
    Current(): T {
        return this.items[this.indx];
    }

    MoveNext(): boolean {
        if (this.indx + this.step < this.items.length && this.indx + this.step >= 0) {
            this.indx += this.step;
            return true;
        }
        return false;
    }

    Reset(): void {
        this.indx = this.defautlInd;
    }

    Count(): number {
        return this.items.length;
    }
}