import { IEnumerable } from "./interfaces/IEnumerable";
import { IEnumerator } from "./interfaces/IEnumerator";

export function GetIndex<T>(enumerable: IEnumerable<T>, value: T): number {
    let enumerator: IEnumerator<T> = enumerable.GetEnumerator();

    for (let index: number = 0; enumerator.MoveNext(); index++)
        if (enumerator.Current() === value)
            return index;
    
    return -1;
}