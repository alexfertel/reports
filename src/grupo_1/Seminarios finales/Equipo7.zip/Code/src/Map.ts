import { IEnumerable } from "./interfaces/IEnumerable";
import { IEnumerator } from "./interfaces/IEnumerator";
import { Enumerator } from "./Enumerator";

export function Map<T, R>(enumerable: IEnumerable<T>, transforme: (item: T) => R): IEnumerator<R> {
    let ans: R[] = [];
    let enumerator: IEnumerator<T> = enumerable.GetEnumerator();

    while (enumerator.MoveNext())
        ans.push(transforme(enumerator.Current()));
    
    return new Enumerator(ans);
}