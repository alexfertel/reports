import { Enumerator } from "./Enumerator";
import { IEnumerable } from "./interfaces/IEnumerable";
import { IEnumerator } from "./interfaces/IEnumerator";

export class Queue<T> implements IEnumerable<T> {
    items: T[];

    constructor(items: T[] = []) {
        this.items = items;
    }

    Enqueue(item: T) {
        this.items.push(item);
    }

    Dequeue(): T | undefined {
        if (this.IsEmpty())
            throw new Error("Queue empty");
        
        return this.items.shift();
    }

    Peek(): T {
        if (this.IsEmpty())
            throw new Error("Queue empty");

        return this.items[0];
    }

    Count(): number {
        return this.items.length;
    }

    IsEmpty(): boolean {
        return this.items.length == 0;
    }

    GetEnumerator(): IEnumerator<T> {
        return new Enumerator<T>(this.items);
    }
}