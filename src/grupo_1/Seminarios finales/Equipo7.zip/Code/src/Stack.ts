import { IEnumerable } from "./interfaces/IEnumerable";
import { IEnumerator } from "./interfaces/IEnumerator";
import { Enumerator } from "./Enumerator";

export class Stack<T> implements IEnumerable<T> {

    items: T[];

    constructor(items: T[] = []) {
        this.items = items;
    }

    Push(item: T): void {
        this.items.push(item);
    }

    Pop(): T | undefined {
        if (this.IsEmpty())
            throw new Error("Stack empty");
        
        return this.items.pop();
    }

    Peek(): T {
        if (this.IsEmpty())
            throw new Error("Stack empty");
        
        return this.items[this.Count() - 1];
    }

    Count(): number {
        return this.items.length;
    }

    IsEmpty(): boolean {
        return this.items.length == 0;
    }

    GetEnumerator(): IEnumerator<T> {
        return new Enumerator<T>(this.items, this.Count(), -1);
    }
}