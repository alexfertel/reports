import { Queue } from "./Queue";
import { Stack } from "./Stack";
import { GetIndex } from "./GetIndex";
import { Map } from "./Map";

function queue() {
    let tail: Queue<number> = new Queue<number>();

    for (let i = 0; i < 10; ++i)
        tail.Enqueue(i);
    
    let enumerator = tail.GetEnumerator();

    console.log('=========== Elements Queue: ============');
    while (enumerator.MoveNext())
        console.log(enumerator.Current());
    
    enumerator.Reset();

    console.log('=========== Elements with Map: ============');
    let ans = Map<number, number>(tail, (item) => item * 2);
    while (ans.MoveNext())
        console.log(ans.Current());
}

function stack() {
    let stack: Stack<number> = new Stack<number>();

    for (let i = 0; i < 10; ++i)
        stack.Push(i)

    let enumerator = stack.GetEnumerator();
    
    console.log('=========== Elements Stack: ============');
    while (enumerator.MoveNext()) 
        console.log(enumerator.Current())
    
    console.log(`GetIndex: ${GetIndex(stack, 3)}`)
    
}

queue();
console.log('\n')
stack();