﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace Concurrencia
{
    class SafeCollection<T>
    {
        private ICollection<T> collection;
        public int Count { get { return collection.Count; }}

        public SafeCollection()
        {
            collection = new Collection<T>();
        }

        public void Add(T element)
        {
            Monitor.Enter(collection);
            collection.Add(element);
            Monitor.Exit(collection);
        }

        public void Remove(T element)
        {
            Monitor.Enter(collection);
            collection.Remove(element);
            Monitor.Exit(collection);
        }

    }

    class Storage<T>
    {
        Queue<T> queue = new Queue<T>();
        object notEmpty = new object();
        object notFull = new object();
        int capacity;

        public Storage(int capacity)
        {
            this.capacity = capacity;
        }

        public void Enqueue(T element, string threadId)
        {         
            Monitor.Enter(queue);
            while (queue.Count == capacity)
            {
                Monitor.Exit(queue);
                lock (notFull)
                {
                    Console.WriteLine("{0} -> Waiting for notFull.", threadId);
                    Monitor.Wait(notFull);
                }              
                Monitor.Enter(queue);              
            }
            queue.Enqueue(element);
            Console.WriteLine("{0} -> Enqueue element", threadId);
            Monitor.Exit(queue);

            lock(notEmpty)
                Monitor.Pulse(notEmpty);       
        }

        public T Dequeue(string threadId)
        {        
            Monitor.Enter(queue);          
            while (queue.Count == 0)
            {              
                Monitor.Exit(queue);
                lock(notEmpty)
                {
                    Console.WriteLine("{0} -> Waiting for notEmpty.", threadId);
                    Monitor.Wait(notEmpty);
                }              
                Monitor.Enter(queue);             
            }
            T element = queue.Dequeue();
            Console.WriteLine("{0} -> Dequeue element", threadId);
            Monitor.Exit(queue);

            lock(notFull)
                Monitor.Pulse(notFull);
            
            return element;
        }
    }

    class Producer
    {
        Storage<int> storage;
        string producerId;

        public Producer(Storage<int> storage, string producerId)
        {
            this.storage = storage;
            this.producerId = producerId;
        }

        public Thread Produce()
        {
            Thread t = new Thread(() => {
                for (int i = 0; i < 10; i++)
                {
                    storage.Enqueue(i, producerId);
                }
            });
            t.Name = this.producerId;
            t.Start();
            return t;
        }
    }

    class Consumer
    {
        Storage<int> storage;
        string consumerId;

        public Consumer(Storage<int> storage, string consumerId)
        {
            this.storage = storage;
            this.consumerId = consumerId;
        }

        public Thread Consume()
        {
            Thread t = new Thread(() => {
                for (int i = 0; i < 10; i++)
                {
                    storage.Dequeue(consumerId);
                }
            });
            t.Name = this.consumerId;
            t.Start();
            return t;
        }
    }

  

    class Program
    {
        static void Main(string[] args)
        {
            Storage<int> storage = new Storage<int>(1000);
            Producer p1 = new Producer(storage, "P1");
            Producer p2 = new Producer(storage, "P2");
            Producer p3 = new Producer(storage, "P3");
            Consumer c1 = new Consumer(storage, "C1");
            Consumer c2 = new Consumer(storage, "C2");
            Consumer c3 = new Consumer(storage, "C3");

            List<Thread> threads = new List<Thread>();

            threads.Add(p1.Produce());
            threads.Add(p2.Produce());
            threads.Add(p3.Produce());
            threads.Add(c1.Consume());
            threads.Add(c2.Consume());
            threads.Add(c3.Consume());

            foreach (var t in threads)
            {
                t.Join();
                Console.WriteLine(t.Name);
            }
        }
    }
}
