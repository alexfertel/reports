
# La Concurrencia en los Contenedores

## Que es concurrencia

> La concurrencia es la propiedad de los sistemas en la cual los procesos de un computo se hacen simultaneamente, y pueden interactuar entre ellos. Esto provoca que el procesador ejecute multiple tareas al intercalarlas en un intervalo de tiempo.

A menudo el termino concurrencia es confundido con paralelismo, tratandolos como el mismo concepto. Sin embargo cuando nos referimos a paralelismo es el hecho de ejecutar tareas, cada una en nucleos separados, posibilitando la ejecucion secuencial de todas sus instrucciones, sin las interrupciones caracteristicas de la concurrencia. La concurrencia completa las tareas en periodos de tiempo superpuestos, sin un orden especifico; mientras que el paralelismo las ejecuta literalmente al mismo tiempo.

### Principales consecuencias de la concurrencia

Al lidiar con varias tareas al mismo tiempo los programas concurrentes pueden presentar varios problemas:

- Race condition: es cuando mas de un hilo trata de ejecutar la seccion critica de un programa y lo logra, obteniendo asi resultados indeseados.
- Deadlock: es el bloqueo permanente de un conjunto de procesos de un sistema concurrente que compiten por recursos del sistema o bien se comunican entre ellos.

## Monitor

Para controlar los problemas anteriores en la implementacion de este seminario nos basamos en el uso de `Monitor` en C#, debido a:

- Garantiza que solo un subproceso a la vez este ejecutando cierta parte del codigo (seccion critica).
- Permite esperar hasta que haya notificaciones y hacerlas para un objeto determinado.
- Se debe utilizar para bloquear tipos por referencia y no por valor. Cuando se utiliza una variable de tipo por valor, se le aplica la conversion *boxing* como si fuera un objeto; si la misma variable es utilizada nuevamente, se le aplica el proceso de *boxing* como si fuera un objeto independiente y el subproceso no se bloquea.

La clase Monitor le permite sincronizar el acceso a una región de código tomando y liberando un bloqueo en un objeto en particular llamando a los métodos Monitor.Enter , Monitor.TryEnter y Monitor.Exit. Los bloqueos de objetos brindan la capacidad de restringir el acceso a un bloque de código, comúnmente llamado sección crítica. Mientras que un hilo posee el bloqueo de un objeto, ningún otro hilo puede adquirir ese bloqueo.

La siguiente información se mantiene para cada objeto sincronizado:

- Una referencia al hilo que actualmente mantiene el candado.
- Una referencia a una cola ***Ready***, que contiene los subprocesos que están listos para obtener el bloqueo.
- Una referencia a una cola de ***Wait***, que contiene los subprocesos que están esperando la notificación de un cambio en el estado del objeto bloqueado.

Acciones que se pueden realizar con `Monitor`:

| Accion              | Descripcion                                                                                                                                                                                                                                                                                                                        |
| ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Enter`, `TryEnter` | Esta accion marca el comienzo de una zona critica al bloquear el objeto, a la cual ningun otro hilo puede acceder a menos que este ejecutando las instrucciones dentro.                                                                                                                                                            |
| `Wait`              | Libera el bloqueo del objeto para permitir que otros subprocesos accedan a el. El subproceso que realiza la llamada espera mientras otro subproceso accede al objeto. Las señales de `Pulse` se utilizan para notificar a los hilos en espera sobre cambios en el estado de un objeto.                                             |
| `Pulse`, `PulseAll` | Envía una señal a uno o más subprocesos en espera. La señal notifica a un subproceso en espera que el estado del objeto bloqueado ha cambiado y el propietario del bloqueo está listo para liberarlo. El subproceso en espera se coloca en la cola ***Ready*** del objeto para que eventualmente reciba el bloqueo para el objeto. |
| `Exit`              | Libera el bloqueo de un objeto. Esta acción también marca el final de una sección crítica protegida por el objeto bloqueado.                                                                                                                                                                                                       |

## Safe Collection

Implemente el tipo `SafeCollection` de forma tal que no tenga problemas a la hora de acceder a sus funcionalidades (`Add`, `Remove`, `Count`) desde varias hebras.

```C#
class SafeCollection<T>
    {
        private Collection<T> collection;
        public int Count { get { return collection.Count; }}

        public SafeCollection()
        {
            collection = new Collection<T>();
        }

        public void Add(T element)
        {
            Monitor.Enter(collection);
            collection.Add(element);
            Monitor.Exit(collection);
        }

        public void Remove(T element)
        {
            Monitor.Enter(collection);
            collection.Remove(element);
            Monitor.Exit(collection);
        }
    }
```

- `collection`: Es el objeto utilizado para almacenar los elementos.
- `Count`: Representa la cantidad de elementos en la coleccion.
- `Add`: Contempla la accion de agregar un nuevo elemento a la coleccion.
- `Remove`: Contempla la accion de eliminar un elemento de la coleccion.

Se garantiza que en las acciones que modifican la coleccion (`Add`, `Remove`) exista un unico proceso ejecutandolas, utilizando `Monitor.Enter` y `Monitor.Exit` como delimitantes de la seccion critica.

## Problema Productor-Consumidor

Un ejemplo de un problema de concurrencia seria el siguiente: dado dos procesos A (productor) y B (consumidor) que se ejecutan indefinidamente en el tiempo, el proceso A debe recibir tiempo de ejecucion antes que B. Tras esto, el proceso B debe recibir su oportunidad de ejecucion, dando paso de nuevo al proceso A, y asi sucesivamente, siguiendo un esquema de alternancia estricta.

El planificador de procesos, al desconocer la naturaleza de los procesos y sus objetivos, no dispone de informacion suficiente para garantizar la secuencia de ejecucion descrita en el ejemplo anterior. De este modo, suponiendo que ambos procesos se encuentran en estado ready, podrian selecionar al proceso B para pasar a estado activo antes de selecionar al proceso A, situacion que no es deseada.

## Storage

Implemente el tipo `Storage`. Este objeto funciona similar a una cola con la excepcion de que cuando no hay elementos en la cola, la hebra que realizo el llamdo se bloquea, hasta tanto otra hebra agregue algun elemento a la cola. Esta cola tiene una capacidad fija definida desde un principio. Si la capacidad de la cola se completo y se intenta poner un nuevo elemento, la hebra se pondra en espera hasta que sea retirado uno.

```C#
class Storage<T>
    {
        Queue<T> queue = new Queue<T>();
        object notEmpty = new object();
        object notFull = new object();
        int capacity;

        public Storage(int capacity)
        {
            this.capacity = capacity;
        }

        public void Enqueue(T element, string threadId)
        {
            Monitor.Enter(queue);
            while (queue.Count == capacity)
            {
                Monitor.Exit(queue);
                lock (notFull)
                {
                    Console.WriteLine("{0} -> Waiting for notFull.", threadId);
                    Monitor.Wait(notFull);
                }
                Monitor.Enter(queue);
            }
            queue.Enqueue(element);
            Console.WriteLine("{0} -> Enqueue element", threadId);
            Monitor.Exit(queue);

            lock(notEmpty)
                Monitor.Pulse(notEmpty);
        }

        public T Dequeue(string threadId)
        {
            Monitor.Enter(queue);
            while (queue.Count == 0)
            {
                Monitor.Exit(queue);
                lock(notEmpty)
                {
                    Console.WriteLine("{0} -> Waiting for notEmpty.", threadId);
                    Monitor.Wait(notEmpty);
                }
                Monitor.Enter(queue);
            }
            T element = queue.Dequeue();
            Console.WriteLine("{0} -> Dequeue element", threadId);
            Monitor.Exit(queue);

            lock(notFull)
                Monitor.Pulse(notFull);

            return element;
        }
    }
```

- `queue`: Es la cola base en la cual se almacenan los elementos.
- `notEmpty`: Objeto utilizado para indicar si la cola se encuentra vacia o no, al ser bloqueado o liberado.
- `notFull`: Objeto utilizado para indicar si la cola se encuentra llena o no, al ser bloqueado o liberado.
- `capacity`: Indica la capacidad de la cola.
- `Enqueue`: Inserta un nuevo elemento en la cola en el momento que pueda, es decir, que se cumpla `notFull`.
- `Dequeue`: Retira el primer elemento en la cola en el momento que pueda, es decir, que se cumpla `notEmpty`.

### Productor - Consumidor

```C#
class Producer
    {
        Storage<int> storage;
        string producerId;

        public Producer(Storage<int> storage, string producerId)
        {
            this.storage = storage;
            this.producerId = producerId;
        }

        public Thread Produce()
        {
            Thread t = new Thread(() => {
                for (int i = 0; i < 3; i++)
                {
                    storage.Enqueue(i, producerId);
                }
            });
            t.Name = this.producerId;
            t.Start();
            return t;
        }
    }

    class Consumer
    {
        Storage<int> storage;
        string consumerId;

        public Consumer(Storage<int> storage, string consumerId)
        {
            this.storage = storage;
            this.consumerId = consumerId;
        }

        public Thread Consume()
        {
            Thread t = new Thread(() => {
                for (int i = 0; i < 3; i++)
                {
                    storage.Dequeue(consumerId);
                }
            });
            t.Name = this.consumerId;
            t.Start();
            return t;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Storage<int> storage = new Storage<int>(2);
            Producer p1 = new Producer(storage, "P1");
            Producer p2 = new Producer(storage, "P2");
            Producer p3 = new Producer(storage, "P3");
            Consumer c1 = new Consumer(storage, "C1");
            Consumer c2 = new Consumer(storage, "C2");
            Consumer c3 = new Consumer(storage, "C3");

            List<Thread> threads = new List<Thread>();

            threads.Add(p1.Produce());
            threads.Add(p2.Produce());
            threads.Add(p3.Produce());
            threads.Add(c1.Consume());
            threads.Add(c2.Consume());
            threads.Add(c3.Consume());

            foreach (var t in threads)
            {
                t.Join();
                Console.WriteLine(t.Name);
            }
        }
    }
```

Output:

![output](img.png)
